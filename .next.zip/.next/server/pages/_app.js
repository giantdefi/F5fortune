"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 173:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./node_modules/next/dynamic.js
var dynamic = __webpack_require__(5152);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
// EXTERNAL MODULE: ./src/redux/reducers/SoundReducer.js
var SoundReducer = __webpack_require__(8475);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
// EXTERNAL MODULE: ./src/redux/reducers/ModalReducer.js
var ModalReducer = __webpack_require__(536);
// EXTERNAL MODULE: ./src/redux/reducers/ErrorReducer.js
var ErrorReducer = __webpack_require__(2009);
// EXTERNAL MODULE: ./src/redux/reducers/PackageReducer.js
var PackageReducer = __webpack_require__(3126);
// EXTERNAL MODULE: external "@reduxjs/toolkit"
var toolkit_ = __webpack_require__(5184);
;// CONCATENATED MODULE: ./src/redux/reducers/ConstantReducer.js

const initialState = {
    app_title: false,
    app_domain: false,
    app_description: false,
    app_tags: false,
    app_currency: false,
    admin_wallet: false,
    splittoEWallet: false,
    splittoRwallet: false
};
const ConstantSlice = (0,toolkit_.createSlice)({
    name: "constant",
    initialState,
    reducers: {
        setApp_title: (state, action)=>{
            state.app_title = action.payload;
        },
        setApp_domain: (state, action)=>{
            state.app_domain = action.payload;
        },
        setApp_description: (state, action)=>{
            state.app_description = action.payload;
        },
        setApp_tags: (state, action)=>{
            state.app_tags = action.payload;
        },
        setApp_currency: (state, action)=>{
            state.app_currency = action.payload;
        },
        setAdmin_wallet: (state, action)=>{
            state.admin_wallet = action.payload;
        },
        setTo_E_Wallet: (state, action)=>{
            state.to_E_Wallet = action.payload;
        },
        setTo_R_Wallet: (state, action)=>{
            state.to_R_Wallet = action.payload;
        },
        setSplittoEWallet: (state, action)=>{
            state.splittoEWallet = action.payload;
        },
        setSplittoRwallet: (state, action)=>{
            state.splittoRwallet = action.payload;
        }
    }
});
const { setApp_title , setApp_domain , setApp_description , setApp_tags , setApp_currency , setAdmin_wallet , setSplittoEWallet , setSplittoRwallet , setTo_E_Wallet , setTo_R_Wallet ,  } = ConstantSlice.actions;
/* harmony default export */ const ConstantReducer = (ConstantSlice.reducer);

// EXTERNAL MODULE: ./src/redux/reducers/AuthReducer.js
var AuthReducer = __webpack_require__(2719);
;// CONCATENATED MODULE: ./src/components/dataLoader/dataLoader.js





//--- redux store---------------------------------------






//--------------------------------------
function BtnActivateBinary() {
    const router = (0,router_.useRouter)();
    const { 0: spinner , 1: setSpinner  } = (0,external_react_.useState)(false);
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { token , userid , isLogin  } = (0,external_react_redux_.useSelector)((state)=>state.AuthReducer
    );
    const { username , password  } = (0,external_react_redux_.useSelector)((state)=>state.FormReducer
    );
    (0,external_react_.useEffect)(()=>{
        if (isLogin) {
            loadConstants();
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        isLogin
    ]);
    const loadConstants = async ()=>{
        const URL = "https://api.fivefortunefx.com";
        return external_axios_default()({
            url: `${URL}/users/pre-load?userid=${userid}`,
            method: "GET",
            "headers": {
                "Authorization": token,
                accept: "application/json",
                "content-type": "application/json"
            }
        }).then(async (response)=>{
            const data = response.data.data;
            //   console.log(data)
            dispatch(setApp_title(data.app_title));
            dispatch(setApp_domain(data.app_domain));
            dispatch(setApp_description(data.app_description));
            dispatch(setApp_tags(data.app_tags));
            dispatch(setApp_currency(data.app_currency));
            dispatch(setAdmin_wallet(data.admin_wallet_crypto));
            dispatch(setSplittoEWallet(data.alocate_E_Wallet));
            dispatch(setSplittoRwallet(data.alocate_R_Wallet));
            const userData = response.data.userData[0];
            //   console.log( userData)
            dispatch((0,AuthReducer/* setName */.qC)(userData.name));
            dispatch((0,AuthReducer/* setIsActive */.WA)(userData.isActive));
            dispatch((0,AuthReducer/* setIsAdmin */.nZ)(userData.isAdmin));
            dispatch((0,AuthReducer/* setEWallet */.Ze)(userData.e_wallet));
            dispatch((0,AuthReducer/* setRWallet */.ql)(userData.r_wallet));
            dispatch((0,AuthReducer/* setWD_request */.KA)(userData.total_wd));
            dispatch((0,AuthReducer/* setTotal_wd_paid */.sJ)(userData.total_wd_paid));
            const adminPackage = response.data.packages;
            //  console.log( adminPackage)
            dispatch((0,PackageReducer/* setAdmin_packages */.UJ)(adminPackage));
        // dispatch(setMypackages(adminPackage)) 
        }).catch(function(error) {
            console.log(error);
            return dispatch((0,ModalReducer/* setModalMessage */.Zu)({
                type: "danger",
                title: "Network Error!",
                message: "Please check your Internet connection"
            }));
        });
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {});
};

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/layout/MainFooter.js




//---- REDUX STORE ---------------------

//--------------------------------------
function MainFooter() {
    const router = (0,router_.useRouter)();
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { isLogin , username  } = (0,external_react_redux_.useSelector)((state)=>state.AuthReducer
    );
    const { width , domain  } = (0,external_react_redux_.useSelector)((state)=>state.GeneralReducer
    );
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("footer", {
            className: "p-4 bg-gray-800 items-center justify-center flex flex-col text-white w-full",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                className: "text-sm text-gray-200 sm:text-center mx-auto",
                children: [
                    "Copyright \xa9 ",
                    domain,
                    " All Rights Reserved"
                ]
            })
        })
    });
};

// EXTERNAL MODULE: ./src/redux/reducers/ReferralReducer.js
var ReferralReducer = __webpack_require__(2686);
// EXTERNAL MODULE: ./src/redux/reducers/FormReducer.js
var FormReducer = __webpack_require__(915);
;// CONCATENATED MODULE: ./src/components/reflink/ReferralLink.js




//---- REDUX STORE ---------------------



//--------------------------------------
function ReferralLink() {
    const router = (0,router_.useRouter)();
    const { ref  } = router.query;
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { refLink , masterRef  } = (0,external_react_redux_.useSelector)((state)=>state.ReferralReducer
    );
    const { loginSidebar  } = (0,external_react_redux_.useSelector)((state)=>state.MainmenuReducer
    );
    (0,external_react_.useEffect)(()=>{
        if (ref && ref.length <= 10) {
            CheckRefUserExist();
        } else {
            dispatch((0,ReferralReducer/* setRefLink */.rt)(masterRef));
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        ref
    ]);
    async function CheckRefUserExist() {
        const URL = "https://api.fivefortunefx.com";
        return external_axios_default()({
            url: `${URL}/users/isActive?user=${ref}`,
            method: "GET"
        }).then(async (response)=>{
            if (response.data.isSuccess) {
                dispatch((0,ReferralReducer/* setRefLink */.rt)(ref));
                dispatch((0,FormReducer/* setFormSponsor */.Wf)(ref));
            } else {
                dispatch((0,ReferralReducer/* setRefLink */.rt)(masterRef));
                dispatch((0,FormReducer/* setFormSponsor */.Wf)(masterRef));
            }
        }).catch(function(error) {
            console.log(error);
        });
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {});
};

;// CONCATENATED MODULE: ./src/components/inputforms/register/Sponsor.js


//--- redux store---------------------------------------




//-------------------------------------------------------
function Sponsor() {
    const inputRef = (0,external_react_.useRef)();
    // redux store
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { sponsor  } = (0,external_react_redux_.useSelector)((state)=>state.FormReducer
    );
    const { formError  } = (0,external_react_redux_.useSelector)((state)=>state.ErrorReducer
    );
    const { refLink  } = (0,external_react_redux_.useSelector)((state)=>state.ReferralReducer
    );
    const { loginSidebar  } = (0,external_react_redux_.useSelector)((state)=>state.MainmenuReducer
    );
    // console.log('ref link : ' + refLink)
    // IF HAS REF LINK
    (0,external_react_.useEffect)(()=>{
        if (refLink) {
            setTimeout(()=>{
                dispatch((0,FormReducer/* setFormSponsor */.Wf)(refLink));
            }, 500);
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        refLink,
        loginSidebar
    ]);
    const handleChange = (e)=>{
        dispatch((0,ErrorReducer/* setError */.sT)(false));
        const { name , value  } = e.target;
        if (value.length <= 50) {
            dispatch((0,FormReducer/* setFormSponsor */.Wf)(value.toUpperCase().trim()));
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "relative z-0 w-full mb-4 group",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex justify-between ",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-sm ",
                        children: "Your Sponsor or Get from Referral Link"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                    type: "text",
                    className: "block py-4 px-0 w-full text-lg text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer",
                    placeholder: " ",
                    required: true,
                    name: "sponsor",
                    value: sponsor || "",
                    onChange: handleChange
                }),
                formError && formError.path === "sponsor" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                    className: "text-red-800 ml-2 text-sm animated backInLeft items-center flex",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "icofont-arrow-right animate-ping mr-2"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                            className: "text-red-900 ",
                            children: [
                                " ",
                                formError.message
                            ]
                        })
                    ]
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./src/components/inputforms/register/Username.js


//--- redux store---------------------------------------



//-------------------------------------------------------
function Username() {
    const inputRef = useRef();
    // redux store
    const dispatch = useDispatch();
    const { username  } = useSelector((state)=>state.FormReducer
    );
    const { formError  } = useSelector((state)=>state.ErrorReducer
    );
    // handle on input value change
    const handleChange = async (e)=>{
        dispatch(setError(false));
        const { name , value  } = e.target;
        if (value.length <= 10) {
            const re = /^[0-9a-zA-Z]*$/;
            if (re.test(value)) {
                if (value.length <= 10) {
                    //  const userUppercase = (value.toUpperCase().trim())
                    dispatch(setFormUsername(value));
                }
            }
        }
    };
    // Focus input element on submit if no value
    useEffect(()=>{
        if (formError && formError.path === "username") {
        //    inputRef.current.focus()
        // inputRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' }) // make it on center of the screen 
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        formError
    ]);
    // const handleModalKeyboard = () => {
    //     dispatch(setModalKeyboardUsername(true))
    // }
    return /*#__PURE__*/ _jsx(_Fragment, {
        children: /*#__PURE__*/ _jsxs("div", {
            className: "relative z-0 w-full mb-4 group",
            children: [
                /*#__PURE__*/ _jsx("input", {
                    type: "text",
                    className: "block py-2.5 px-0 w-full text-sm text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer",
                    placeholder: " ",
                    required: true,
                    name: "username",
                    value: username || "",
                    onChange: handleChange
                }),
                /*#__PURE__*/ _jsx("label", {
                    className: "peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 rtl:peer-focus:left-auto peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6",
                    children: "Create Username"
                }),
                formError && formError.path === "username" && /*#__PURE__*/ _jsxs("p", {
                    className: "text-red-800 ml-2 text-sm animated backInLeft items-center flex",
                    children: [
                        /*#__PURE__*/ _jsx("i", {
                            className: "icofont-arrow-right animate-ping mr-2"
                        }),
                        /*#__PURE__*/ _jsxs("span", {
                            className: "text-red-900 ",
                            children: [
                                " ",
                                formError.message
                            ]
                        })
                    ]
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./src/components/inputforms/login/Username.js


//--- redux store---------------------------------------



//-------------------------------------------------------
function Username_Username() {
    const inputRef = useRef();
    // redux store
    const dispatch = useDispatch();
    const { username  } = useSelector((state)=>state.FormReducer
    );
    const { formError  } = useSelector((state)=>state.ErrorReducer
    );
    // handle on input value change
    const handleChange = async (e)=>{
        dispatch(setError(false));
        const { name , value  } = e.target;
        if (value.length <= 10) {
            const re = /^[0-9a-zA-Z]*$/;
            if (re.test(value)) {
                if (value.length <= 10) {
                    //  const userUppercase = (value.toUpperCase().trim())
                    dispatch(setFormUsername(value));
                }
            }
        }
    };
    // Focus input element on submit if no value
    useEffect(()=>{
        if (formError && formError.path === "username") {
        //    inputRef.current.focus()
        // inputRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' }) // make it on center of the screen 
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        formError
    ]);
    // const handleModalKeyboard = () => {
    //     dispatch(setModalKeyboardUsername(true))
    // }
    return /*#__PURE__*/ _jsx(_Fragment, {
        children: /*#__PURE__*/ _jsxs("div", {
            children: [
                /*#__PURE__*/ _jsx("label", {
                    className: "block text-sm font-medium text-gray-900 dark:text-white",
                    children: "Your Username"
                }),
                /*#__PURE__*/ _jsx("input", {
                    type: "text",
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white",
                    name: "username",
                    value: username || "",
                    onChange: handleChange
                }),
                formError && formError.path === "username" && /*#__PURE__*/ _jsxs("p", {
                    className: "text-red-800 ml-2 text-sm animated backInLeft items-center flex",
                    children: [
                        /*#__PURE__*/ _jsx("i", {
                            className: "icofont-arrow-right animate-ping mr-2"
                        }),
                        /*#__PURE__*/ _jsxs("span", {
                            className: "text-red-900 ",
                            children: [
                                " ",
                                formError.message
                            ]
                        })
                    ]
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./src/components/inputforms/login/Password.js


//--- redux store---------------------------------------



//-------------------------------------------------------
function Password() {
    const inputRef = useRef();
    const { 0: showPassword , 1: setShowPassword  } = useState(false);
    // redux store
    const dispatch = useDispatch();
    const { password  } = useSelector((state)=>state.FormReducer
    );
    const { formError  } = useSelector((state)=>state.ErrorReducer
    );
    // handle on input value change
    const handleChange = (e)=>{
        dispatch(setError(false));
        const { name , value  } = e.target;
        if (value.length <= 20) {
            dispatch(setFormPassword(value));
        }
    };
    // Focus input element on submit if no value
    useEffect(()=>{
        if (formError && formError.path === "password") {
        // inputRef.current.focus()
        // inputRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' }) // make it on center of the screen 
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        formError
    ]);
    const togglePassword = ()=>{
        if (showPassword) {
            setShowPassword(false);
        } else {
            setShowPassword(true);
        }
    };
    return /*#__PURE__*/ _jsx(_Fragment, {
        children: /*#__PURE__*/ _jsxs("div", {
            children: [
                /*#__PURE__*/ _jsxs("div", {
                    className: "flex justify-between text-white",
                    children: [
                        /*#__PURE__*/ _jsx("label", {
                            className: "block text-sm font-medium text-gray-900 dark:text-white",
                            children: "Enter Password "
                        }),
                        !showPassword ? /*#__PURE__*/ _jsxs("div", {
                            onClick: togglePassword,
                            className: "flex justify-center items-center cursor-pointer text-gray-900",
                            children: [
                                /*#__PURE__*/ _jsx("p", {
                                    className: "text-sm",
                                    children: " Hide "
                                }),
                                /*#__PURE__*/ _jsxs("p", {
                                    children: [
                                        "   ",
                                        /*#__PURE__*/ _jsx("i", {
                                            className: "icofont-eye-blocked text-xl ml-2"
                                        })
                                    ]
                                })
                            ]
                        }) : /*#__PURE__*/ _jsxs("div", {
                            onClick: togglePassword,
                            className: "flex justify-center items-center cursor-pointer text-gray-900",
                            children: [
                                /*#__PURE__*/ _jsx("p", {
                                    className: "text-sm",
                                    children: " Show "
                                }),
                                /*#__PURE__*/ _jsxs("p", {
                                    children: [
                                        "   ",
                                        /*#__PURE__*/ _jsx("i", {
                                            className: "icofont-eye text-xl ml-2"
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ _jsx("input", {
                    className: "bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white",
                    type: !showPassword ? "password" : "text",
                    name: "password",
                    value: password || "",
                    onChange: handleChange
                }),
                formError && formError.path === "password" && /*#__PURE__*/ _jsxs("p", {
                    className: "text-red-800 ml-2 text-sm animated backInLeft items-center flex",
                    children: [
                        /*#__PURE__*/ _jsx("i", {
                            className: "icofont-arrow-right animate-ping mr-2"
                        }),
                        /*#__PURE__*/ _jsx("span", {
                            className: "text-red-900 ",
                            children: formError.message
                        })
                    ]
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./src/components/inputforms/login/Email.js


//--- redux store---------------------------------------



//-------------------------------------------------------
function EmailForgot() {
    const inputRef = (0,external_react_.useRef)();
    // redux store
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { email  } = (0,external_react_redux_.useSelector)((state)=>state.FormReducer
    );
    const { formError  } = (0,external_react_redux_.useSelector)((state)=>state.ErrorReducer
    );
    // handle on input value change
    const handleChange = (e)=>{
        dispatch((0,ErrorReducer/* setError */.sT)(false));
        const { name , value  } = e.target;
        if (value.length <= 40) {
            dispatch((0,FormReducer/* setFormEmail */.DP)(value.trim()));
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "max-w-sm mx-auto",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                    className: "block mb-2 text-sm font-medium text-gray-900 dark:text-white",
                    children: "Your Email : "
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "inline-flex items-center px-3 text-sm text-gray-900 bg-gray-200 border border-e-0 border-gray-300 rounded-s-md dark:bg-gray-600 dark:text-gray-400 dark:border-gray-600",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                className: "w-4 h-4 text-gray-500 dark:text-gray-400",
                                "aria-hidden": "true",
                                xmlns: "http://www.w3.org/2000/svg",
                                fill: "currentColor",
                                viewBox: "0 0 20 16",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        d: "m10.036 8.278 9.258-7.79A1.979 1.979 0 0 0 18 0H2A1.987 1.987 0 0 0 .641.541l9.395 7.737Z"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        d: "M11.241 9.817c-.36.275-.801.425-1.255.427-.428 0-.845-.138-1.187-.395L0 2.6V14a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V2.5l-8.759 7.317Z"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            type: "email",
                            className: "rounded-none rounded-e-lg bg-gray-50 border border-gray-300 text-gray-900 focus:ring-blue-500 focus:border-blue-500 block flex-1 min-w-0 w-full text-sm p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white text-lg",
                            placeholder: "jhondoe@gmail.com",
                            name: "email",
                            value: email || "",
                            onChange: handleChange
                        })
                    ]
                }),
                formError && formError.path === "email" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                    className: "text-red-800 ml-2 text-sm animated backInLeft items-center flex",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "icofont-arrow-right animate-ping mr-2"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                            className: "text-red-900 ",
                            children: [
                                " ",
                                formError.message
                            ]
                        })
                    ]
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./src/components/inputforms/register/Email.js


//--- redux store---------------------------------------



//-------------------------------------------------------
function Email_EmailForgot() {
    const inputRef = (0,external_react_.useRef)();
    // redux store
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { email  } = (0,external_react_redux_.useSelector)((state)=>state.FormReducer
    );
    const { formError  } = (0,external_react_redux_.useSelector)((state)=>state.ErrorReducer
    );
    // handle on input value change
    const handleChange = (e)=>{
        dispatch((0,ErrorReducer/* setError */.sT)(false));
        const { name , value  } = e.target;
        if (value.length <= 40) {
            dispatch((0,FormReducer/* setFormEmail */.DP)(value.trim()));
        }
    };
    // Focus input element on submit if no value
    (0,external_react_.useEffect)(()=>{
        if (formError && formError.path === "email") {
        //    inputRef.current.focus()
        //  inputRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' }) // make it on center of the screen 
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        formError
    ]);
    // console.log(username)
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "relative z-0 w-full mb-4 group",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                    type: "text",
                    className: "block py-4 px-0 w-full text-lg text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer",
                    placeholder: " ",
                    required: true,
                    name: "email",
                    value: email || "",
                    onChange: handleChange
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                    className: "peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 rtl:peer-focus:left-auto peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6",
                    children: "Email address"
                }),
                formError && formError.path === "email" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                    className: "text-red-800 ml-2 text-sm animated backInLeft items-center flex",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "icofont-arrow-right animate-ping mr-2"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                            className: "text-red-900 ",
                            children: [
                                " ",
                                formError.message
                            ]
                        })
                    ]
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./src/components/inputforms/register/Phone.js


//--- redux store---------------------------------------



//-------------------------------------------------------
function Phone() {
    const inputRef = (0,external_react_.useRef)();
    // redux store
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { phone  } = (0,external_react_redux_.useSelector)((state)=>state.FormReducer
    );
    const { formError  } = (0,external_react_redux_.useSelector)((state)=>state.ErrorReducer
    );
    // handle on input value change
    const handleChange = (e)=>{
        dispatch((0,ErrorReducer/* setError */.sT)(false));
        const { name , value  } = e.target;
        if (value.length <= 18) {
            dispatch((0,FormReducer/* setFormPhone */.qQ)(value));
        }
    };
    // Focus input element on submit if no value
    (0,external_react_.useEffect)(()=>{
        if (formError && formError.path === "phone") {
        //   inputRef.current.focus()
        //   inputRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' }) // make it on center of the screen 
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        formError
    ]);
    const handleModalKeyboard = ()=>{
        dispatch(setModalKeyboardPhone(true));
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "relative z-0 w-full mb-4 group",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                    type: "text",
                    className: "block py-4 px-0 w-full text-lg text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer",
                    placeholder: " ",
                    required: true,
                    name: "phone",
                    value: phone || "",
                    onChange: handleChange
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                    className: "peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 rtl:peer-focus:left-auto peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6",
                    children: "Handphone"
                }),
                formError && formError.path === "phone" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                    className: "text-red-800 ml-2 text-sm animated backInLeft items-center flex",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "icofont-arrow-right animate-ping mr-2"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                            className: "text-red-900 ",
                            children: [
                                " ",
                                formError.message
                            ]
                        })
                    ]
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./src/components/inputforms/register/FirstName.js


//--- redux store---------------------------------------



//-------------------------------------------------------
function FirstName_Username() {
    const inputRef = (0,external_react_.useRef)();
    // redux store
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { firstName  } = (0,external_react_redux_.useSelector)((state)=>state.FormReducer
    );
    const { formError  } = (0,external_react_redux_.useSelector)((state)=>state.ErrorReducer
    );
    // handle on input value change
    const handleChange = async (e)=>{
        dispatch((0,ErrorReducer/* setError */.sT)(false));
        const { name , value  } = e.target;
        if (value.length <= 10) {
            dispatch((0,FormReducer/* setFirstName */.lC)(value));
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "relative z-0 w-full mb-4 group",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                    type: "text",
                    className: "block py-4 px-0 w-full text-lg text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer",
                    placeholder: " ",
                    required: true,
                    name: "firstName",
                    value: firstName || "",
                    onChange: handleChange
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                    className: "peer-focus:font-medium absolute text-lg text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 rtl:peer-focus:left-auto peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6",
                    children: "FirstName"
                }),
                formError && formError.path === "firstName" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                    className: "text-red-800 ml-2 text-sm animated backInLeft items-center flex",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "icofont-arrow-right animate-ping mr-2"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                            className: "text-red-900 ",
                            children: [
                                " ",
                                formError.message
                            ]
                        })
                    ]
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./src/components/inputforms/register/LastName.js


//--- redux store---------------------------------------



//-------------------------------------------------------
function LastName_Username() {
    const inputRef = (0,external_react_.useRef)();
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { lastName  } = (0,external_react_redux_.useSelector)((state)=>state.FormReducer
    );
    const { formError  } = (0,external_react_redux_.useSelector)((state)=>state.ErrorReducer
    );
    const handleChange = async (e)=>{
        dispatch((0,ErrorReducer/* setError */.sT)(false));
        const { name , value  } = e.target;
        if (value.length <= 10) {
            dispatch((0,FormReducer/* setLastName */.ZQ)(value));
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "relative z-0 w-full mb-4 group",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                    type: "text",
                    className: "block py-4 px-0 w-full text-lg text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer",
                    placeholder: " ",
                    required: true,
                    name: "lastName",
                    value: lastName || "",
                    onChange: handleChange
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("label", {
                    className: "peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 rtl:peer-focus:left-auto peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6",
                    children: "Last Name"
                }),
                formError && formError.path === "lastName" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                    className: "text-red-800 ml-2 text-sm animated backInLeft items-center flex",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "icofont-arrow-right animate-ping mr-2"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                            className: "text-red-900 ",
                            children: [
                                " ",
                                formError.message
                            ]
                        })
                    ]
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./src/components/inputforms/register/Password.js


//--- redux store---------------------------------------



//-------------------------------------------------------
function Password_Password() {
    const inputRef = (0,external_react_.useRef)();
    const { 0: showPassword , 1: setShowPassword  } = (0,external_react_.useState)(false);
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { password  } = (0,external_react_redux_.useSelector)((state)=>state.FormReducer
    );
    const { formError  } = (0,external_react_redux_.useSelector)((state)=>state.ErrorReducer
    );
    const handleChange = (e)=>{
        dispatch((0,ErrorReducer/* setError */.sT)(false));
        const { name , value  } = e.target;
        if (value.length <= 20) {
            dispatch((0,FormReducer/* setFormPassword */.cX)(value));
        }
    };
    const togglePassword = ()=>{
        if (showPassword) {
            setShowPassword(false);
        } else {
            setShowPassword(true);
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex justify-end text-white",
                    children: !showPassword ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        onClick: togglePassword,
                        className: "flex justify-center items-center cursor-pointer text-gray-900",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-sm",
                                children: " Hide "
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    "   ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "icofont-eye-blocked text-xl ml-2"
                                    })
                                ]
                            })
                        ]
                    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        onClick: togglePassword,
                        className: "flex justify-center items-center cursor-pointer text-gray-900",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-sm",
                                children: " Show "
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    "   ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "icofont-eye text-xl ml-2"
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "relative z-0 w-full group",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            className: "block py-2.5 px-4 w-full text-lg text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-60 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer",
                            placeholder: " ",
                            type: !showPassword ? "password" : "text",
                            name: "password",
                            value: password || "",
                            onChange: handleChange
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                            className: "peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6",
                            children: "Password"
                        })
                    ]
                }),
                formError && formError.path === "password" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                    className: "text-red-800 ml-2 text-sm animated backInLeft items-center flex",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "icofont-arrow-right animate-ping mr-2"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "text-red-900 ",
                            children: formError.message
                        })
                    ]
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./src/components/inputforms/register/ConfirmPassword.js


//--- redux store---------------------------------------



//-------------------------------------------------------
function ConfirmPassword() {
    const inputRef = (0,external_react_.useRef)();
    const { 0: showPassword , 1: setShowPassword  } = (0,external_react_.useState)(false);
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { confirmPassword  } = (0,external_react_redux_.useSelector)((state)=>state.FormReducer
    );
    const { formError  } = (0,external_react_redux_.useSelector)((state)=>state.ErrorReducer
    );
    const handleChange = (e)=>{
        dispatch((0,ErrorReducer/* setError */.sT)(false));
        const { name , value  } = e.target;
        if (value.length <= 50) {
            dispatch((0,FormReducer/* setFormConfirmPassword */.PT)(value.trim()));
        }
    };
    const togglePassword = ()=>{
        if (showPassword) {
            setShowPassword(false);
        } else {
            setShowPassword(true);
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex justify-end text-white",
                    children: !showPassword ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        onClick: togglePassword,
                        className: "flex justify-center items-center cursor-pointer text-gray-900",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-sm",
                                children: " Hide "
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    "   ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "icofont-eye-blocked text-xl ml-2"
                                    })
                                ]
                            })
                        ]
                    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        onClick: togglePassword,
                        className: "flex justify-center items-center cursor-pointer text-gray-900",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-sm",
                                children: " Show "
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    "   ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "icofont-eye text-xl ml-2"
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "relative z-0 w-full group",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            className: "block py-4 px-0 w-full text-lg text-gray-900 bg-transparent border-0 border-b-2 border-gray-300 appearance-none dark:text-white dark:border-gray-60 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer",
                            placeholder: " ",
                            type: !showPassword ? "password" : "text",
                            name: "confirmPassword",
                            value: confirmPassword || "",
                            onChange: handleChange
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                            className: "peer-focus:font-medium absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-6 scale-75 top-3 -z-10 origin-[0] peer-focus:start-0 rtl:peer-focus:translate-x-1/4 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-6",
                            children: "Confirm Password"
                        })
                    ]
                }),
                formError && formError.path === "confirmPassword" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                    className: "text-red-800 ml-2 text-sm animated backInLeft items-center flex",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "icofont-arrow-right animate-ping mr-2"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "text-red-900 ",
                            children: formError.message
                        })
                    ]
                })
            ]
        })
    });
};

// EXTERNAL MODULE: ./src/redux/reducers/MainmenuReducer.js
var MainmenuReducer = __webpack_require__(5772);
;// CONCATENATED MODULE: ./src/redux/reducers/UsersReducer.js

const UsersReducer_initialState = {
    fullname: false,
    handphone: false,
    email: false,
    address: false,
    city: false,
    province: false,
    country: false,
    postcode: false,
    avatar: false,
    geolocation: false,
    isGetGeocodeOK: false,
    verified: false,
    // change password
    currentPassword: false,
    newPassword: false,
    confirmPassword: false,
    serverTime: false,
    allowReloadData: false,
    allowReloadUsers: false,
    // userClone: false,
    masterCloner: false,
    myclonedUsers: false,
    userClone: false,
    allowReloadClonUser: false,
    cloneLoginUsername: false,
    allowReloadPage: false,
    warningCreateClone: false
};
const UsersSlice = (0,toolkit_.createSlice)({
    name: "users",
    initialState: UsersReducer_initialState,
    reducers: {
        setNameFull: (state, action)=>{
            state.fullname = action.payload;
        },
        setHandphone: (state, action)=>{
            state.handphone = action.payload;
        },
        setEmail: (state, action)=>{
            state.email = action.payload;
        },
        setAddress: (state, action)=>{
            state.address = action.payload;
        },
        setCity: (state, action)=>{
            state.city = action.payload;
        },
        setProvince: (state, action)=>{
            state.province = action.payload;
        },
        setCountry: (state, action)=>{
            state.country = action.payload;
        },
        setPostcode: (state, action)=>{
            state.postcode = action.payload;
        },
        setAvatar: (state, action)=>{
            state.avatar = action.payload;
        },
        setGeoLocation: (state, action)=>{
            state.geolocation = action.payload;
        },
        setIsGetGeocodeOK: (state, action)=>{
            state.isGetGeocodeOK = action.payload;
        },
        setIsVerified: (state, action)=>{
            state.verified = action.payload;
        },
        setCurrentPassword: (state, action)=>{
            state.currentPassword = action.payload;
        },
        setNewPassword: (state, action)=>{
            state.newPassword = action.payload;
        },
        setConfirmPassword: (state, action)=>{
            state.confirmPassword = action.payload;
        },
        setServerTime: (state, action)=>{
            state.serverTime = action.payload;
        },
        setAllowReloadData: (state, action)=>{
            state.allowReloadData = action.payload;
        },
        setAllowReloadUsers: (state, action)=>{
            state.allowReloadUsers = action.payload;
        },
        setCloneUser: (state, action)=>{
            state.userClone = action.payload;
        },
        setMasterCloner: (state, action)=>{
            state.masterCloner = action.payload;
        },
        setMyclonedUsers: (state, action)=>{
            state.myclonedUsers = action.payload;
        },
        setAllowReloadClonUser: (state, action)=>{
            state.allowReloadClonUser = action.payload;
        },
        setCloneLoginUsername: (state, action)=>{
            state.cloneLoginUsername = action.payload;
        },
        setAllowReloadPage: (state, action)=>{
            state.allowReloadPage = action.payload;
        },
        setWarningCreateClone: (state, action)=>{
            state.warningCreateClone = action.payload;
        },
        resetUsers: ()=>UsersReducer_initialState
    }
});
const { resetUsers , setNameFull , setHandphone , setEmail , setAddress , setCity , setProvince , setCountry , setPostcode , setAvatar , setGeoLocation , setIsGetGeocodeOK , setIsVerified , setCurrentPassword , setNewPassword , setConfirmPassword , setServerTime , setAllowReloadData , setAllowReloadUsers , setWarningCreateClone , setMasterCloner , setCloneUser , setMyclonedUsers , setAllowReloadClonUser , setCloneLoginUsername , setAllowReloadPage  } = UsersSlice.actions;
/* harmony default export */ const UsersReducer = (UsersSlice.reducer);

;// CONCATENATED MODULE: ./src/redux/actions/BtnRegister.js




//--- redux store---------------------------------------







//--------------------------------------
function BtnRegister_BtnActivateBinary() {
    const router = (0,router_.useRouter)();
    const { 0: spinner , 1: setSpinner  } = (0,external_react_.useState)(false);
    const dispatch = (0,external_react_redux_.useDispatch)();
    // const { username, token } = useSelector((state) => state.AuthReducer)
    const { password , confirmPassword , firstName , lastName , phone , email , sponsor  } = (0,external_react_redux_.useSelector)((state)=>state.FormReducer
    );
    const handleLogin = async ()=>{
        dispatch((0,ErrorReducer/* setError */.sT)(false));
        setSpinner(true);
        setTimeout(()=>{
            handleLoginDelay();
        }, 100);
    };
    // console.log(isUserHasChecked)
    const handleLoginDelay = async ()=>{
        window.scrollTo({
            top: 0,
            left: 0,
            behavior: "smooth"
        });
        if (!sponsor) {
            setSpinner(false);
            dispatch((0,SoundReducer/* setPlaySound */.Pl)("error"));
            return dispatch((0,ErrorReducer/* setError */.sT)({
                path: "sponsor",
                message: "Sponsor is required"
            }));
        }
        if (!sponsor) {
            setSpinner(false);
            dispatch((0,SoundReducer/* setPlaySound */.Pl)("error"));
            return dispatch((0,ErrorReducer/* setError */.sT)({
                path: "sponsor",
                message: "Sponsor is required"
            }));
        }
        if (!firstName) {
            setSpinner(false);
            dispatch((0,SoundReducer/* setPlaySound */.Pl)("error"));
            return dispatch((0,ErrorReducer/* setError */.sT)({
                path: "firstName",
                message: "First Name is required"
            }));
        }
        if (!lastName) {
            setSpinner(false);
            dispatch((0,SoundReducer/* setPlaySound */.Pl)("error"));
            return dispatch((0,ErrorReducer/* setError */.sT)({
                path: "lastName",
                message: "Last Name is required"
            }));
        }
        if (!email) {
            setSpinner(false);
            dispatch((0,SoundReducer/* setPlaySound */.Pl)("error"));
            return dispatch((0,ErrorReducer/* setError */.sT)({
                path: "email",
                message: "Email is required"
            }));
        }
        if (!phone) {
            setSpinner(false);
            dispatch((0,SoundReducer/* setPlaySound */.Pl)("error"));
            return dispatch((0,ErrorReducer/* setError */.sT)({
                path: "phone",
                message: "Handphone is required"
            }));
        }
        if (!password) {
            setSpinner(false);
            dispatch((0,SoundReducer/* setPlaySound */.Pl)("error"));
            return dispatch((0,ErrorReducer/* setError */.sT)({
                path: "password",
                message: "Password is required"
            }));
        }
        if (!confirmPassword) {
            setSpinner(false);
            dispatch((0,SoundReducer/* setPlaySound */.Pl)("error"));
            return dispatch((0,ErrorReducer/* setError */.sT)({
                path: "confirmPassword",
                message: "Confirm Password is required"
            }));
        }
        if (password !== confirmPassword) {
            setSpinner(false);
            dispatch((0,SoundReducer/* setPlaySound */.Pl)("error"));
            return dispatch((0,ErrorReducer/* setError */.sT)({
                path: "confirmPassword",
                message: "confirm Password does not match"
            }));
        }
        const data1 = {
            email,
            password,
            confirmPassword,
            firstName,
            lastName,
            phone,
            email,
            sponsor
        };
        console.log(data1);
        const URL = "https://api.fivefortunefx.com";
        return external_axios_default()({
            url: `${URL}/users/register`,
            method: "POST",
            data: data1,
            "headers": {
                //  'Authorization': token,
                accept: "application/json",
                "content-type": "application/json"
            }
        }).then(async (response)=>{
            const data = response.data;
            if (data.isSuccess) {
                dispatch((0,SoundReducer/* setPlaySound */.Pl)("success"));
                const token = response.data.token;
                const dataLogin = response.data.dataLogin;
                dispatch((0,AuthReducer/* setIsLogin */.$M)(true));
                dispatch((0,AuthReducer/* setToken */.o4)(token));
                dispatch((0,AuthReducer/* setUserid */.x$)(dataLogin.userid));
                dispatch((0,AuthReducer/* setName */.qC)(dataLogin.name));
                dispatch((0,AuthReducer/* setIsActive */.WA)(dataLogin.isActive));
                dispatch((0,AuthReducer/* setIsAdmin */.nZ)(dataLogin.isAdmin));
                dispatch((0,AuthReducer/* setSponsor */.fc)(dataLogin.sponsor));
                // dispatch(setWallet(dataLogin.wallet)) 
                dispatch((0,MainmenuReducer/* setLoginSidebar */.gu)(false));
                dispatch((0,ModalReducer/* setModalMessage */.Zu)({
                    type: "success",
                    title: "AWESOME",
                    message: "You are now Loged In"
                }));
                return router.push("/users");
            } else {
                setSpinner(false);
                // dispatch(setModalToast({ type: 'error', title: "Activation Fail!", message: response.data.message }))
                return dispatch((0,ErrorReducer/* setError */.sT)({
                    path: response.data.path,
                    message: response.data.message
                }));
            }
        }).catch(function(error) {
            setSpinner(false);
            console.log(error);
            return dispatch((0,ModalReducer/* setModalMessage */.Zu)({
                type: "danger",
                title: "Network Error!",
                message: "Please check your Internet connection"
            }));
        });
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: spinner ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
            className: "w-full my-6 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                    style: {
                        maxWidth: 40
                    },
                    role: "status",
                    className: "mr-4 inline w-6 h-6 text-gray-200 dark:text-gray-300 animate-spin fill-blue-600",
                    viewBox: "0 0 100 101",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            d: "M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z",
                            fill: "currentColor"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            d: "M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z",
                            fill: "currentFill"
                        })
                    ]
                }),
                "processing....."
            ]
        }) : /*#__PURE__*/ jsx_runtime_.jsx("button", {
            onClick: handleLogin,
            className: "w-full my-6 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-lg px-5 py-4 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800",
            children: "  Register"
        })
    });
};

;// CONCATENATED MODULE: ./src/redux/reducers/SidebarReducer.js

/*
THIS IS USED FOR USERS SIDEBAR
*/ const SidebarReducer_initialState = {
    sidebarOpen: true,
    dropdownOpen: 0,
    itemSelected: 0,
    showLogin: true
};
const sidebarSlice = (0,toolkit_.createSlice)({
    name: "sidebar",
    initialState: SidebarReducer_initialState,
    reducers: {
        setSidebarOpen: (state, action)=>{
            state.sidebarOpen = action.payload;
        },
        setDropdownOpen: (state, action)=>{
            state.dropdownOpen = action.payload;
        },
        setItemSelected: (state, action)=>{
            state.itemSelected = action.payload;
        },
        setShowLogin: (state, action)=>{
            state.showLogin = action.payload;
        }
    }
});
// export all action above here 
const { setSidebarOpen , setDropdownOpen , setItemSelected , setShowLogin  } = sidebarSlice.actions;
/* harmony default export */ const SidebarReducer = (sidebarSlice.reducer);

;// CONCATENATED MODULE: ./src/layout/LoginSidebar.js


















//---- REDUX STORE ---------------------









//--------------------------------------
function Home() {
    const dispatch = (0,external_react_redux_.useDispatch)();
    const router = (0,router_.useRouter)();
    const { 0: spinner , 1: setSpinner  } = (0,external_react_.useState)(false);
    const { loginSidebar  } = (0,external_react_redux_.useSelector)((state)=>state.MainmenuReducer
    );
    const { showLogin  } = (0,external_react_redux_.useSelector)((state)=>state.SidebarReducer
    );
    const { 0: password , 1: setPassword  } = (0,external_react_.useState)(false);
    const { formError  } = (0,external_react_redux_.useSelector)((state)=>state.ErrorReducer
    );
    const { isLogin , name: name1  } = (0,external_react_redux_.useSelector)((state)=>state.AuthReducer
    );
    const { 0: showPassword , 1: SetShowPassword  } = (0,external_react_.useState)(false);
    const { email  } = (0,external_react_redux_.useSelector)((state)=>state.FormReducer
    );
    const toggleLogin = ()=>{
        dispatch((0,FormReducer/* resetForm */.Fx)());
        dispatch((0,ErrorReducer/* resetErrors */.n2)());
        if (showLogin) {
            dispatch(setShowLogin(false));
        } else {
            dispatch(setShowLogin(true));
        }
    } // handle on input value change
    ;
    const handleChange = (e)=>{
        dispatch((0,ErrorReducer/* setError */.sT)(false));
        const { name , value  } = e.target;
        if (name === "email") {
            (0,AuthReducer/* setEmail */.vV)(value);
        } else if (name = "password") {
            setPassword(value);
        }
    };
    const togglePassword = ()=>{
        SetShowPassword(!showPassword);
    };
    const handleLogin = ()=>{
        if (!email) {
            setSpinner(false);
            dispatch((0,SoundReducer/* setPlaySound */.Pl)("error"));
            return dispatch((0,ErrorReducer/* setError */.sT)({
                path: "email",
                message: "Email is required"
            }));
        }
        if (!password) {
            setSpinner(false);
            dispatch((0,SoundReducer/* setPlaySound */.Pl)("error"));
            return dispatch((0,ErrorReducer/* setError */.sT)({
                path: "password",
                message: "Password is required"
            }));
        }
        handleLoginDelay();
    };
    const handleLoginDelay = async ()=>{
        const data1 = {
            email,
            password
        };
        setSpinner(true);
        const URL = "https://api.fivefortunefx.com";
        return external_axios_default()({
            url: `${URL}/users/login`,
            method: "POST",
            data: data1,
            "headers": {
                // 'Authorization': token,
                accept: "application/json",
                "content-type": "application/json"
            }
        }).then(async (response)=>{
            const data = response.data;
            setSpinner(false);
            if (data.isSuccess) {
                dispatch((0,SoundReducer/* setPlaySound */.Pl)("success"));
                const token = response.data.token;
                const dataLogin = response.data.dataLogin;
                dispatch((0,AuthReducer/* setIsLogin */.$M)(true));
                dispatch((0,AuthReducer/* setToken */.o4)(token));
                dispatch((0,AuthReducer/* setName */.qC)(dataLogin.name));
                dispatch((0,AuthReducer/* setUserid */.x$)(dataLogin.userid));
                dispatch((0,AuthReducer/* setIsActive */.WA)(dataLogin.isActive));
                dispatch((0,AuthReducer/* setIsAdmin */.nZ)(dataLogin.isAdmin));
                dispatch((0,AuthReducer/* setSponsor */.fc)(dataLogin.sponsor));
                dispatch((0,AuthReducer/* setEWallet */.Ze)(dataLogin.e_wallet));
                dispatch((0,AuthReducer/* setRWallet */.ql)(dataLogin.r_wallet));
                dispatch((0,MainmenuReducer/* setLoginSidebar */.gu)(false));
                dispatch((0,ModalReducer/* setModalMessage */.Zu)({
                    type: "success",
                    title: "AWESOME",
                    message: "You are now Loged In"
                }));
                return router.push("/users");
            } else {
                // dispatch(setModalToast({ type: 'error', title: "Activation Fail!", message: response.data.message }))
                return dispatch((0,ErrorReducer/* setError */.sT)({
                    path: response.data.path,
                    message: response.data.message
                }));
            }
            setSpinner(false);
        }).catch(function(error) {
            setSpinner(false);
            console.log(error);
            return dispatch((0,ModalReducer/* setModalMessage */.Zu)({
                type: "danger",
                title: "Network Error!",
                message: "Please check your Internet connection"
            }));
        });
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            !isLogin && /*#__PURE__*/ jsx_runtime_.jsx(ReferralLink, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                class: `min-h-screen overflow-auto mt-24 pb-40 border-4 border-gray-300  md:mt-16 fixed top-0 right-0 z-40 h-screen p-4 overflow-y-auto transition-transform  bg-white w-96 
    dark:bg-gray-800 ${!loginSidebar && "translate-x-full"}`,
                children: showLogin ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    class: "w-full max-w-sm p-4 bg-white border border-gray-200 rounded-lg shadow sm:p-6 md:p-8 dark:bg-gray-800 dark:border-gray-700",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        class: "space-y-6",
                        action: "#",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                class: "text-xl font-medium text-gray-900 dark:text-white",
                                children: "Please Login"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(EmailForgot, {}),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex justify-between text-white mt-6 mb-4",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                        className: "block text-sm font-medium text-gray-900 dark:text-white mb-1",
                                                        children: "Password : "
                                                    }),
                                                    !showPassword ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        onClick: togglePassword,
                                                        className: "flex justify-center items-center cursor-pointer text-gray-900",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: "text-sm",
                                                                children: " Hide "
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                                children: [
                                                                    "   ",
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                        className: "icofont-eye-blocked text-xl ml-2"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        onClick: togglePassword,
                                                        className: "flex justify-center items-center cursor-pointer text-gray-900",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                                className: "text-sm",
                                                                children: " Show "
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                                children: [
                                                                    "   ",
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                        className: "icofont-eye text-xl ml-2"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                className: "bg-gray-50 border border-gray-300 text-gray-900 rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2 text-lg dark:bg-gray-600 dark:border-gray-500 dark:placeholder-gray-400 dark:text-white",
                                                type: !showPassword ? "password" : "text",
                                                name: "password",
                                                value: password || "",
                                                onChange: handleChange
                                            }),
                                            formError && formError.path === "password" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: "text-red-800 ml-2 text-sm animated backInLeft items-center flex",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "icofont-arrow-right animate-ping mr-2"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "text-red-900 ",
                                                        children: formError.message
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        class: "flex justify-between mt-6",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                class: "flex items-start",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        class: "flex items-center h-5",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                            id: "remember",
                                                            type: "checkbox",
                                                            value: "",
                                                            class: "w-4 h-4 border border-gray-300 rounded bg-gray-50 focus:ring-3 focus:ring-blue-300 dark:bg-gray-700 dark:border-gray-600 dark:focus:ring-blue-600 dark:ring-offset-gray-800 dark:focus:ring-offset-gray-800",
                                                            required: true
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                                        for: "remember",
                                                        class: "ml-2 text-sm font-medium text-gray-900 dark:text-gray-300",
                                                        children: "Remember me"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "#",
                                                class: "ms-auto text-sm text-blue-700 hover:underline dark:text-blue-500",
                                                children: "Lost Password?"
                                            })
                                        ]
                                    }),
                                    spinner ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                        className: "w-full my-6 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                                                style: {
                                                    maxWidth: 40
                                                },
                                                role: "status",
                                                className: "mr-4 inline w-6 h-6 text-gray-200 dark:text-gray-300 animate-spin fill-blue-600",
                                                viewBox: "0 0 100 101",
                                                fill: "none",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        d: "M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z",
                                                        fill: "currentColor"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                        d: "M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z",
                                                        fill: "currentFill"
                                                    })
                                                ]
                                            }),
                                            "processing....."
                                        ]
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        onClick: handleLogin,
                                        className: "w-full my-6 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-lg px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800",
                                        children: "  LOGIN USER"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                class: "flex justify-end",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    onClick: ()=>dispatch((0,MainmenuReducer/* setLoginSidebar */.gu)(false))
                                    ,
                                    className: "w-1/4 my-6 text-white bg-red-700 hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800",
                                    children: "  Close"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                class: "text-sm font-medium text-gray-500 dark:text-gray-300",
                                children: [
                                    "Not registered? ",
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        onClick: toggleLogin,
                                        class: "text-blue-700 hover:underline dark:text-blue-500",
                                        children: "Create account"
                                    })
                                ]
                            })
                        ]
                    })
                }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    class: "max-w-md mx-auto mt-2",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            class: "flex w-full",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: "mb-6 mx-auto text-blue-800",
                                children: "Register your account"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Sponsor, {}),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            class: "grid md:grid-cols-2 md:gap-6",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(FirstName_Username, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(LastName_Username, {})
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Email_EmailForgot, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx(Phone, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx(Password_Password, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx(ConfirmPassword, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx(BtnRegister_BtnActivateBinary, {}),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            class: "text-sm font-medium text-gray-500 dark:text-gray-300",
                            children: [
                                "Already have account? ",
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    onClick: toggleLogin,
                                    class: "text-blue-700 hover:underline dark:text-blue-500",
                                    children: "Login here"
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};

;// CONCATENATED MODULE: ./src/layout/MainTopNavigation.js







//import BtnDemoUser from "redux/actions/BtnDemoUser"
//import BtnActivateUser from "redux/actions/BtnActivateUser"

//---- REDUX STORE ---------------------




//--------------------------------------
function MainHeader() {
    const router = (0,router_.useRouter)();
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { isLogin , username  } = (0,external_react_redux_.useSelector)((state)=>state.AuthReducer
    );
    const { showLogin  } = (0,external_react_redux_.useSelector)((state)=>state.SidebarReducer
    );
    const { toggleLogin  } = (0,external_react_redux_.useSelector)((state)=>state.AuthReducer
    );
    const { loginSidebar  } = (0,external_react_redux_.useSelector)((state)=>state.MainmenuReducer
    );
    const onMenuClick = (link)=>{
        dispatch((0,SoundReducer/* setPlaySound */.Pl)("click"));
        //  setItemLink(link)
        //  setMenuSpinner(true)
        setTimeout(()=>{
            router.push(link);
        }, 100);
    };
    //     const handleToggle = () => {
    //         if(toggleLogin){
    // dispatch(setToggleLogin(false))
    //         }else{
    //             dispatch(setToggleLogin(true))
    //         }
    //     }
    const handleToggle = ()=>{
        dispatch((0,FormReducer/* resetForm */.Fx)());
        dispatch((0,ErrorReducer/* resetErrors */.n2)());
        if (loginSidebar) {
            dispatch((0,MainmenuReducer/* setLoginSidebar */.gu)(false));
        } else {
            dispatch((0,MainmenuReducer/* setLoginSidebar */.gu)(true));
            dispatch((0,MainmenuReducer/* setLeftSidebar */.Gs)(false));
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(ReferralLink, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Home, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("nav", {
                className: "_gradient_mtree p-2 mt-0 fixed w-full z-10 ",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: " mx-auto flex flex-row justify-between",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex h-14 centered sm:justify-center md:justify-start mx-auto sm:mx-0 w-full md:w-80 ",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    onClick: ()=>onMenuClick("/")
                                    ,
                                    className: "flex cursor-pointer w-full",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "/assets/F5-logo.png",
                                        className: "ml-4 h-6 w-[240px] mt-2 animated fadeInDown",
                                        alt: "logo"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    onClick: ()=>onMenuClick("/users")
                                    ,
                                    className: "md:hidden rounded-full w-[65px] h-[65px] mt-4",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "rounded-full cursor-pointer border-2 border-gray-400",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                            src: "/assets/img/banner-1.webp",
                                            className: "rounded-full animated fadeIn",
                                            alt: "VISITOR"
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "flex w-full pt-2 content-center justify-between lg:w-1/2 md:justify-end",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                className: "list-reset flex justify-between flex-1 md:flex-none items-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "mr-3 flex centered",
                                    children: !isLogin ? /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        onClick: handleToggle,
                                        className: "flex justify-center text-sm text-white rounded-full hover:bg-blue-500 transition ease-in-out duration-300 py-1 border-4 border-gray-400 text-xl px-4",
                                        children: showLogin ? "LOGIN" : "REGISTER"
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            onClick: ()=>router.push("/users")
                                            ,
                                            className: "flex justify-center text-sm text-white rounded-full hover:bg-blue-500 transition ease-in-out duration-300 py-1 border-4 border-gray-400 text-xl px-4",
                                            children: "DASHBOARD"
                                        })
                                    })
                                })
                            })
                        })
                    ]
                })
            })
        ]
    });
};

;// CONCATENATED MODULE: ./src/layout/UserTopNavigation.js






const LiveClockDate = (0,dynamic["default"])(null, {
    loadableGenerated: {
        modules: [
            "..\\layout\\UserTopNavigation.js -> " + "./LiveClockDate"
        ]
    },
    ssr: false
});
//---- REDUX STORE ---------------------

function TopNavigation() {
    const router = (0,router_.useRouter)();
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { isLogin , userID , token , name , fullname  } = (0,external_react_redux_.useSelector)((state)=>state.AuthReducer
    );
    const { mainSidebarOpen  } = (0,external_react_redux_.useSelector)((state)=>state.MainmenuReducer
    );
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: mainSidebarOpen ? "ml-64 fixed w-full flex justify-between h-14 text-white z-10 bg-[#8B008B]" : "fixed w-full h-14 flex justify-between text-white z-10 bg-[#8B008B]",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: `flex justify-between items-center transition-all duration-300 ${mainSidebarOpen ? "ml-14" : "ml-16"} } `,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "ml-5 text-gray-200",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                            children: [
                                "    ",
                                /*#__PURE__*/ jsx_runtime_.jsx(LiveClockDate, {})
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "fixed right-0 top-2 flex justify-between items-center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                        className: "flex centered ",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                    className: "text-sm mr-2",
                                    children: [
                                        isLogin ? name : "GUEST",
                                        " "
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    className: " flex-initial rounded-full border-2 border-gray-500 cursor-pointer w-[40px] h-[40px]",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "/assets/img/avatar.webp",
                                        className: "rounded-full w-[40px]",
                                        alt: "users"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    onClick: ()=>router.push("/logout")
                                    ,
                                    className: "mr-14 flex items-center mr-4 hover:text-blue-100 _btn_submit_red ml-2",
                                    children: "  Logout"
                                })
                            ]
                        })
                    })
                })
            ]
        })
    });
};

// EXTERNAL MODULE: ./src/redux/reducers/LoaderReducer.js
var LoaderReducer = __webpack_require__(8847);
;// CONCATENATED MODULE: ./src/menu/SidebarTop.js




//--- redux store---------------------------------------




//-------------------------------------------------------
function SidebarTop() {
    // redux store
    const dispatch = (0,external_react_redux_.useDispatch)();
    const router = (0,router_.useRouter)();
    const { mainSidebarOpen , headerBoardNo  } = (0,external_react_redux_.useSelector)((state)=>state.MainmenuReducer
    );
    const { userAccountID  } = (0,external_react_redux_.useSelector)((state)=>state.UsersReducer
    );
    const toggleSidebar = ()=>{
        mainSidebarOpen ? dispatch((0,MainmenuReducer/* setMainSidebarOpen */.Zd)(false)) : dispatch((0,MainmenuReducer/* setMainSidebarOpen */.Zd)(true));
    };
    const onMenuClick = (link)=>{
        // dispatch(setCurrentBoardLevel(false))
        dispatch((0,SoundReducer/* setPlaySound */.Pl)("click"));
        //  setItemLink(link)
        router.push(link);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex justify-between ",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: " h-12 justify-start flex flex-row pl-5",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: toggleSidebar,
                        className: ` outline-none hover:outline-hidden transition duration-150 ${mainSidebarOpen ? "" : "-rotate-90"} `,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            width: "20px",
                            role: "img",
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 448 512",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                fill: "currentColor",
                                d: "M16 132h416c8.837 0 16-7.163 16-16V76c0-8.837-7.163-16-16-16H16C7.163 60 0 67.163 0 76v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16z"
                            })
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex h-14 centered sm:justify-center md:justify-start mx-auto sm:mx-0 w-full md:w-80 ",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        onClick: ()=>onMenuClick("/")
                        ,
                        className: "flex cursor-pointer w-full",
                        children: mainSidebarOpen ? /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/assets/F5-logo.png",
                            className: "ml-2 h-6 w-[160px] animated fadeInDown",
                            alt: "logo"
                        }) : ""
                    })
                })
            ]
        })
    });
};

// EXTERNAL MODULE: ./src/redux/reducers/SettingReducer.js
var SettingReducer = __webpack_require__(7861);
;// CONCATENATED MODULE: ./src/menu/SidebarBody.js




//--- redux store---------------------------------------





//-------------------------------------------------------
function SidebarBody() {
    const dispatch = (0,external_react_redux_.useDispatch)();
    const router = (0,router_.useRouter)();
    const { currency  } = (0,external_react_redux_.useSelector)((state)=>state.GeneralReducer
    );
    const { isStokist  } = (0,external_react_redux_.useSelector)((state)=>state.AuthReducer
    );
    const { mainSidebarOpen , dropdownOpen , itemSelected  } = (0,external_react_redux_.useSelector)((state)=>state.MainmenuReducer
    );
    const { userAccount , userAccountShort , isWalletRegistered , MAINBalance  } = (0,external_react_redux_.useSelector)((state)=>state.UsersReducer
    );
    const { allowSound  } = (0,external_react_redux_.useSelector)((state)=>state.SettingReducer
    );
    const toggleSound = ()=>{
        if (allowSound) {
            dispatch((0,SettingReducer/* setAllowSound */.qr)(false));
        } else {
            dispatch((0,SoundReducer/* setPlaySound */.Pl)("good"));
            dispatch((0,SettingReducer/* setAllowSound */.qr)(true));
        }
    };
    const toggleSidebar = ()=>{
        mainSidebarOpen ? dispatch((0,MainmenuReducer/* setMainSidebarOpen */.Zd)(false)) : dispatch((0,MainmenuReducer/* setMainSidebarOpen */.Zd)(true));
    };
    const handleDropdownToggle = (n)=>{
        if (dropdownOpen === n) {
            dispatch((0,MainmenuReducer/* setDropdownOpen */.vh)(0));
        } else {
            dispatch((0,MainmenuReducer/* setDropdownOpen */.vh)(n));
        }
    };
    const handleHomePage = (link)=>{
        alert(link);
        router.push(link);
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: `${mainSidebarOpen ? "w-64" : "w-14"} fixed flex flex-col h-[70%]  left-0 
      font-semibold  text-white transition-all duration-300  z-10 bg-[#1d3030] `,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                className: "flex flex-col",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        className: `${dropdownOpen === 0 ? "bg-white bg-opacity-5" : "bg-transparent"} border-gray-400 border-opacity-20  border-b `,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/users",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                className: "flex flex-row justify-between items-center h-16 hover:bg-white hover:bg-opacity-10 text-white-600 pl-3 ",
                                children: [
                                    !mainSidebarOpen && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "ml-1",
                                        onClick: toggleSidebar,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "icofont-home text-red-300 text-xl"
                                        })
                                    }),
                                    mainSidebarOpen && /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "flex flex-col",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: "ml-2 tracking-wide truncate text-sm",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "icofont-home text-yellow-300 text-xl mr-2"
                                                    }),
                                                    "HOME  DASHBOARD "
                                                ]
                                            })
                                        })
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                        className: `${dropdownOpen === 1 ? "bg-white bg-opacity-5" : "bg-transparent"} border-gray-400 border-opacity-20  border-b `,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    onClick: ()=>handleDropdownToggle(1)
                                    ,
                                    className: "flex flex-row justify-between items-center h-16 hover:bg-white hover:bg-opacity-10 text-white-600 pl-3 ",
                                    children: [
                                        !mainSidebarOpen && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "ml-1",
                                            onClick: toggleSidebar,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                width: "24px",
                                                className: "h-6 w-6 text-yellow-500",
                                                fill: "currentColor",
                                                viewBox: "0 0 20 20",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2H5zM11 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V5zM11 13a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"
                                                })
                                            })
                                        }),
                                        mainSidebarOpen && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "flex flex-col",
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                        className: "ml-2 tracking-wide truncate text-sm",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "icofont-certificate-alt-1 text-red-300 text-xl"
                                                            }),
                                                            "  PACKAGES"
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "mr-4",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                        width: "24px",
                                                        className: `fill-current h-6 w-6 transform  transition duration-150 ease-in-out ${dropdownOpen === 1 ? "" : "-rotate-90"} `,
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        viewBox: "0 0 20 20",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                            d: "M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: mainSidebarOpen && dropdownOpen === 1 ? "d-block animated fadeIn bg-gray-800 py-2 pb-6" : "hidden",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "cursor-pointer hover:text-green-300",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            onClick: ()=>router.push("/users/packages")
                                            ,
                                            className: ` flex flex-row items-center h-10  pl-6 
                    ${itemSelected === 1 && dropdownOpen === 1 && "bg-white bg-opacity-10"}`,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: "text-sm ",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "icofont-id-card text-2xl text-yellow-300 hover:text-green-300 "
                                                    }),
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        className: "ml-4",
                                                        children: "Packages"
                                                    })
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "cursor-pointer hover:text-green-300",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            onClick: ()=>router.push("/users/my-packages")
                                            ,
                                            className: ` flex flex-row items-center h-10  pl-6 
                    ${itemSelected === 2 && dropdownOpen === 1 && "bg-white bg-opacity-10"}`,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: "text-sm ",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "icofont-chart-growth text-2xl mr-4 text-yellow-300"
                                                    }),
                                                    " My Packages"
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "cursor-pointer hover:text-green-300",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            onClick: ()=>router.push("/users/history-redeem-package")
                                            ,
                                            className: ` flex flex-row items-center h-10  pl-6 
                    ${itemSelected === 2 && dropdownOpen === 1 && "bg-white bg-opacity-10"}`,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: "text-sm ",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "icofont-chart-growth text-2xl mr-4 text-yellow-300"
                                                    }),
                                                    " History Redeem Packages"
                                                ]
                                            })
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                        className: `${dropdownOpen === 2 ? "bg-white bg-opacity-5" : "bg-transparent"} border-gray-400 border-opacity-20  border-b `,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    onClick: ()=>handleDropdownToggle(2)
                                    ,
                                    className: "flex flex-row justify-between items-center h-16 hover:bg-white hover:bg-opacity-10 text-white-600 pl-3 ",
                                    children: [
                                        !mainSidebarOpen && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "ml-1",
                                            onClick: toggleSidebar,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                width: "24px",
                                                className: "h-6 w-6 text-yellow-500",
                                                fill: "currentColor",
                                                viewBox: "0 0 20 20",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2H5zM11 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V5zM11 13a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"
                                                })
                                            })
                                        }),
                                        mainSidebarOpen && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "flex flex-col",
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                        className: "ml-2 text-sm tracking-wide truncate uppercase",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "icofont-electron text-red-300 text-lg"
                                                            }),
                                                            " TRANSACTION"
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "mr-4",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                        width: "24px",
                                                        className: `fill-current h-6 w-6 transform  transition duration-150 ease-in-out ${dropdownOpen === 2 ? "" : "-rotate-90"} `,
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        viewBox: "0 0 20 20",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                            d: "M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: mainSidebarOpen && dropdownOpen === 2 ? "d-block animated fadeIn bg-gray-800 py-2 pb-6" : "hidden",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "cursor-pointer hover:text-green-300",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            onClick: ()=>router.push("/users/deposit")
                                            ,
                                            className: ` flex flex-row items-center h-10  pl-6 
                    ${itemSelected === 3 && dropdownOpen === 2 && "bg-white bg-opacity-10"}`,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: "text-sm ",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "icofont-arrow-right text-yellow-400"
                                                    }),
                                                    " Deposit Wallet"
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "cursor-pointer hover:text-green-300",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            onClick: ()=>router.push("/users/history-deposit")
                                            ,
                                            className: ` flex flex-row items-center h-10  pl-6 
                    ${itemSelected === 3 && dropdownOpen === 2 && "bg-white bg-opacity-10"}`,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: "text-sm ",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "icofont-arrow-right text-yellow-400"
                                                    }),
                                                    " History Deposit Wallet"
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "cursor-pointer hover:text-green-300",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            onClick: ()=>router.push("/users/wd-request")
                                            ,
                                            className: ` flex flex-row items-center h-10  pl-6 
                    ${itemSelected === 4 && dropdownOpen === 2 && "bg-white bg-opacity-10"}`,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: "text-sm ",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "icofont-arrow-right text-yellow-400"
                                                    }),
                                                    " WD Request"
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "cursor-pointer hover:text-green-300",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            onClick: ()=>router.push("/users/history-wd-request")
                                            ,
                                            className: ` flex flex-row items-center h-10  pl-6 
                    ${itemSelected === 4 && dropdownOpen === 2 && "bg-white bg-opacity-10"}`,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: "text-sm ",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "icofont-arrow-right text-yellow-400"
                                                    }),
                                                    " History WD Request"
                                                ]
                                            })
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                        className: `${dropdownOpen === 3 ? "bg-white bg-opacity-5" : "bg-transparent"} border-gray-400 border-opacity-20  border-b `,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    onClick: ()=>handleDropdownToggle(3)
                                    ,
                                    className: "flex flex-row justify-between items-center h-16 hover:bg-white hover:bg-opacity-10 text-white-600 pl-3 ",
                                    children: [
                                        !mainSidebarOpen && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "ml-1",
                                            onClick: toggleSidebar,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                width: "24px",
                                                className: "h-6 w-6 text-yellow-500",
                                                fill: "currentColor",
                                                viewBox: "0 0 20 20",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2H5zM11 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V5zM11 13a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"
                                                })
                                            })
                                        }),
                                        mainSidebarOpen && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "flex flex-col",
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                        className: "ml-2 text-sm tracking-wide truncate uppercase",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "icofont-flora-flower text-green-300 text-lg"
                                                            }),
                                                            " BONUS"
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "mr-4",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                        width: "24px",
                                                        className: `fill-current h-6 w-6 transform  transition duration-150 ease-in-out ${dropdownOpen === 3 ? "" : "-rotate-90"} `,
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        viewBox: "0 0 20 20",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                            d: "M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: mainSidebarOpen && dropdownOpen === 3 ? "d-block animated fadeIn bg-gray-800 py-2 pb-6" : "hidden",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "cursor-pointer hover:text-green-300",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            onClick: ()=>router.push("/users/referrals")
                                            ,
                                            className: ` flex flex-row items-center h-10  pl-6 
                    ${itemSelected === 2 && dropdownOpen === 1 && "bg-white bg-opacity-10"}`,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: "text-sm ",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "icofont-chart-flow text-2xl mr-2 text-yellow-300"
                                                    }),
                                                    " My Referrals"
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "cursor-pointer hover:text-green-300",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            onClick: ()=>router.push("/users/refferals-bonus")
                                            ,
                                            className: ` flex flex-row items-center h-10  pl-6 
                    ${itemSelected === 5 && dropdownOpen === 3 && "bg-white bg-opacity-10"}`,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: "text-sm ",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "icofont-contact-add text-lg mr-1 text-yellow-300 hover:text-green-300"
                                                    }),
                                                    " Referral Bonus"
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "cursor-pointer hover:text-green-300",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            onClick: ()=>router.push("/users/matching-bonus")
                                            ,
                                            className: ` flex flex-row items-center h-10  pl-6 
                    ${itemSelected === 6 && dropdownOpen === 3 && "bg-white bg-opacity-10"}`,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: "text-sm ",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "icofont-hand-drag2 text-lg mr-1 text-yellow-300 hover:text-green-300"
                                                    }),
                                                    " Matching Bonus"
                                                ]
                                            })
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                        className: `${dropdownOpen === 6 ? "bg-white bg-opacity-5" : "bg-transparent"} border-gray-400 border-opacity-20  border-b `,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    onClick: ()=>handleDropdownToggle(6)
                                    ,
                                    className: "flex flex-row justify-between items-center h-16 hover:bg-white hover:bg-opacity-10 text-white-600 pl-3 ",
                                    children: [
                                        !mainSidebarOpen && /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "ml-1",
                                            onClick: toggleSidebar,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                width: "24px",
                                                className: "h-6 w-6 text-yellow-500",
                                                fill: "currentColor",
                                                viewBox: "0 0 20 20",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2H5zM11 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V5zM11 13a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"
                                                })
                                            })
                                        }),
                                        mainSidebarOpen && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "flex flex-col",
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                        className: "ml-2 text-sm tracking-wide truncate uppercase",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "icofont-gear text-red-300 text-lg"
                                                            }),
                                                            " SETTINGS"
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "mr-4",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                        width: "24px",
                                                        className: `fill-current h-6 w-6 transform  transition duration-150 ease-in-out ${dropdownOpen === 6 ? "" : "-rotate-90"} `,
                                                        xmlns: "http://www.w3.org/2000/svg",
                                                        viewBox: "0 0 20 20",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                            d: "M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: mainSidebarOpen && dropdownOpen === 6 ? "d-block animated fadeIn bg-gray-800 py-2 pb-6" : "hidden",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "cursor-pointer hover:text-green-300",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            onClick: ()=>router.push("/users/change-password")
                                            ,
                                            className: ` flex flex-row items-center h-10  pl-6 
                    ${itemSelected === 14 && dropdownOpen === 6 && "bg-white bg-opacity-10"}`,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: "text-sm ",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "icofont-lock text-lg mr-1 text-yellow-300 hover:text-green-300"
                                                    }),
                                                    " Change Login Password"
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        className: "cursor-pointer hover:text-green-300",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            onClick: ()=>router.push("/users/change-email")
                                            ,
                                            className: ` flex flex-row items-center h-10  pl-6 
                    ${itemSelected === 14 && dropdownOpen === 6 && "bg-white bg-opacity-10"}`,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: "text-sm ",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "icofont-email text-lg mr-1 text-yellow-300 hover:text-green-300"
                                                    }),
                                                    " Change Email"
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            onClick: toggleSound,
                                            className: ` cursor-pointer flex flex-row items-center h-10  pl-6 
                    ${itemSelected === 15 && dropdownOpen === 6 && "bg-white bg-opacity-10"}`,
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                className: "text-sm ",
                                                children: [
                                                    allowSound ? /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "icofont-audio text-xl mr-2 text-green-400 "
                                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "icofont-ui-mute text-xl mr-2 text-green-400"
                                                    }),
                                                    " Sound Setting"
                                                ]
                                            })
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
};

;// CONCATENATED MODULE: ./src/menu/SidebarFooter.js


//import Link from 'next/link'

//--- redux store---------------------------------------

//-------------------------------------------------------
function SidebarFooter() {
    // redux store
    const router = (0,router_.useRouter)();
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { mainSidebarOpen  } = (0,external_react_redux_.useSelector)((state)=>state.MainmenuReducer
    );
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {});
};

;// CONCATENATED MODULE: ./src/menu/FirebaseSidebar.js





//--- redux store---------------------------------------


//-------------------------------------------------------
function FirebaseSidebar() {
    const outsideRef = (0,external_react_.useRef)(null);
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { mainSidebarOpen  } = (0,external_react_redux_.useSelector)((state)=>state.MainmenuReducer
    );
    const { 0: screenSize , 1: setScreenSize  } = (0,external_react_.useState)(false);
    const { 0: width , 1: setWidth  } = (0,external_react_.useState)(window.innerWidth);
    (0,external_react_.useEffect)(()=>{
        const handleResize = ()=>{
            setWidth(window.innerWidth);
        };
        window.addEventListener("resize", handleResize);
        return ()=>{
            window.removeEventListener("resize", handleResize);
        };
    }, []);
    (0,external_react_.useEffect)(()=>{
        if (width <= 1000) {
            dispatch((0,MainmenuReducer/* setMainSidebarOpen */.Zd)(false));
        } else {
            dispatch((0,MainmenuReducer/* setMainSidebarOpen */.Zd)(true));
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        width
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            ref: outsideRef,
            style: {
                zIndex: 46
            },
            className: `flex flex-col min-h-screen  z-30 text-white  bg-[#051e34ff]
        fixed transition-all duration-300 ${mainSidebarOpen ? " w-64 " : "w-14 "} `,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "h-[25%] bg-slate-800",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(SidebarTop, {})
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "h-[70%] bg-slate-800 ",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(SidebarBody, {})
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "h-[5%] z-30 overflow-x-hidden bg-blue-900 pt-1",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(SidebarFooter, {})
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./src/components/modal/ModalMessage.js


//--- redux store---------------------------------------


//-------------------------------------------------------
// note : props is get from parent componenet which call this modal
function ModalMessage() {
    const outsideRef = (0,external_react_.useRef)(null);
    const overlayRef = (0,external_react_.useRef)(null);
    // redux store
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { modalMessage  } = (0,external_react_redux_.useSelector)((state)=>state.ModalReducer
    );
    const handleModalClose = ()=>{
        document.body.classList.remove("overflow-hidden"); // prevent body scroll on modal open
        if (outsideRef.current) {
            outsideRef.current.classList.add("zoomOut");
            overlayRef.current.classList.add("fadeOut");
        }
        setTimeout(()=>{
            dispatch((0,ModalReducer/* setModalMessage */.Zu)(false));
        }, 500);
    };
    /* ---- click outside modal to close modal -----
    Must be set modal open from parent 
    Please inspect Body must add class 'overflow-hidden' to enable click outside
  */ (0,external_react_.useEffect)(()=>{
        if (modalMessage) {
            setTimeout(()=>{
                const checkIfClickedOutside = (e)=>{
                    if (outsideRef.current && !outsideRef.current.contains(e.target)) {
                        handleModalClose();
                        document.body.classList.remove("overflow-hidden");
                    }
                };
                document.addEventListener("click", checkIfClickedOutside);
                return ()=>{
                    document.removeEventListener("click", checkIfClickedOutside);
                };
            }, 100);
            setTimeout(()=>{
                handleModalClose();
            }, 5000);
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        modalMessage
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "_modal_message animated",
            ref: overlayRef,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "relative shadow-full mx-auto z-50 overflow-y-auto animated fadeInDown min-w-[350px]",
                ref: outsideRef,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "icofont-close-circled absolute top-0 right-0 text-3xl text-white cursor-pointer m-2",
                        onClick: handleModalClose
                    }),
                    modalMessage.type === "success" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "_gradient_puple flex flex-row items-center p-5 rounded-2xl border-2 ",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex items-center bg-green-100 border-2 border-yellow-500 justify-center rounded-full h-10 w-10 flex-shrink-0 rounded-2xl-full",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-green-500",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "icofont-check-circled text-4xl"
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "alert-content ml-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "alert-title text-lg text-white",
                                        children: modalMessage.title || "Transaction Success!"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "text-sm text-white",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            dangerouslySetInnerHTML: {
                                                __html: modalMessage.message
                                            }
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    modalMessage.type === "danger" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-row items-center bg-red-600 p-5 rounded-2xl border-4 border-gray-200",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex items-center justify-center h-10 w-10 flex-shrink-0 rounded-2xl-full",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-red-500",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "icofont-network-tower text-4xl text-white animate-ping"
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "alert-content ml-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "alert-title text-lg text-white",
                                        children: modalMessage.title
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "text-sm text-white",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            dangerouslySetInnerHTML: {
                                                __html: modalMessage.message
                                            }
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    modalMessage.type === "error" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-row items-center bg-red-600 p-5 rounded-2xl border-4 border-gray-200",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex items-center justify-center h-10 w-10 flex-shrink-0 rounded-2xl-full",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-red-500",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "icofont-network-tower text-4xl text-white"
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "alert-content ml-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "alert-title text-lg text-white",
                                        children: modalMessage.title || "Transaction Fail!"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "text-sm text-white",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            dangerouslySetInnerHTML: {
                                                __html: modalMessage.message
                                            }
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    modalMessage.type === "warning" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-row items-center bg-yellow-700 p-5 rounded-2xl border-2 ",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex items-center bg-yellow-100 border-2 border-yellow-500 justify-center h-10 w-10 flex-shrink-0 rounded-2xl-full",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-yellow-900",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                        style: {
                                            maxWidth: 40
                                        },
                                        fill: "currentColor",
                                        viewBox: "0 0 20 20",
                                        className: "h-6 w-6",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            fillRule: "evenodd",
                                            d: "M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z",
                                            clipRule: "evenodd"
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "alert-content ml-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "alert-title text-lg text-white",
                                        children: modalMessage.title || "Warning!"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "text-sm ",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "text-white",
                                            dangerouslySetInnerHTML: {
                                                __html: modalMessage.message
                                            }
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    modalMessage.type === "info" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-row items-center bg-blue-800 p-5 rounded-2xl border-4 border-gray-200",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex items-center bg-blue-100 border-2 border-blue-500 justify-center h-10 w-10 flex-shrink-0 rounded-2xl-full",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-blue-500",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                        style: {
                                            maxWidth: 40
                                        },
                                        fill: "currentColor",
                                        viewBox: "0 0 20 20",
                                        className: "h-6 w-6",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            fillRule: "evenodd",
                                            d: "M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z",
                                            clipRule: "evenodd"
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "alert-content ml-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "alert-title text-lg text-white",
                                        children: modalMessage.title || "Info!"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "text-sm text-white",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            dangerouslySetInnerHTML: {
                                                __html: modalMessage.message
                                            }
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    modalMessage.type === "flashout" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-row items-center _gradient_purple p-5 rounded-2xl border-4 ",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex items-center bg-white rounded-full border-2 border-white justify-center h-14 w-15 flex-shrink-0 rounded-2xl-full",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-blue-500 ",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "/assets/img/loadcat.gif",
                                        alt: "banner"
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "alert-content ml-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "alert-title text-lg text-white bold",
                                        children: modalMessage.title || "Warning!"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "text-sm ",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "text-white",
                                            dangerouslySetInnerHTML: {
                                                __html: modalMessage.message
                                            }
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    modalMessage.type === "completed" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-row items-center bg-yellow-700 p-5 rounded-2xl border-4 border-gray-200",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex items-center bg-white rounded-full border-2 border-white justify-center h-14 w-15 flex-shrink-0 rounded-2xl-full",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: "text-blue-500 ",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "/assets/img/loadcat.gif",
                                        alt: "banner"
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "alert-content ml-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "alert-title text-lg text-white",
                                        children: modalMessage.title || "Info!"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "text-sm text-white",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            dangerouslySetInnerHTML: {
                                                __html: modalMessage.message
                                            }
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
};

;// CONCATENATED MODULE: ./src/components/modal/ModalToast.js


//--- redux store---------------------------------------


//-------------------------------------------------------
// note : props is get from parent componenet which call this modal
function ModalToast_ModalMessage() {
    const outsideRef = (0,external_react_.useRef)(null);
    const overlayRef = (0,external_react_.useRef)(null);
    // redux store
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { modalToast  } = (0,external_react_redux_.useSelector)((state)=>state.ModalReducer
    );
    const handleModalClose = ()=>{
        document.body.classList.remove("overflow-hidden"); // prevent body scroll on modal open
        if (outsideRef.current) {
            outsideRef.current.classList.add("zoomOut");
        // overlayRef.current.classList.add('fadeOut');
        }
        setTimeout(()=>{
            dispatch((0,ModalReducer/* setModalToast */.WA)(false));
        }, 500);
    };
    /* ---- click outside modal to close modal -----
    Must be set modal open from parent 
    Please inspect Body must add class 'overflow-hidden' to enable click outside
  */ (0,external_react_.useEffect)(()=>{
        if (modalToast) {
            setTimeout(()=>{
                const checkIfClickedOutside = (e)=>{
                    if (outsideRef.current && !outsideRef.current.contains(e.target)) {
                        handleModalClose();
                        document.body.classList.remove("overflow-hidden");
                    }
                };
                document.addEventListener("click", checkIfClickedOutside);
                return ()=>{
                    document.removeEventListener("click", checkIfClickedOutside);
                };
            }, 100);
        //   setTimeout(() => {
        //     handleModalClose()
        //   }, 5000) 
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        modalToast
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "fixed w-full inset-0 overflow-hidden flex justify-center items-center animated",
            style: {
                zIndex: 100
            },
            ref: overlayRef,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "bg-slate-100 relative border-2 shadow-2xl mx-auto rounded-xl z-50 overflow-y-auto w-96 animated zoomInDown",
                ref: outsideRef,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "icofont-close-circled absolute top-1 right-2 text-3xl text-orange-400 cursor-pointer",
                        onClick: ()=>handleModalClose()
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "modal-content py-4 px-4",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex centered",
                                children: [
                                    modalToast.type === "success" && /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "icofont-check-circled text-[100px] text-green-700 animated bounceInDown"
                                    }),
                                    modalToast.type === "error" && /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "icofont-close-circled text-[100px] text-red-700 animated bounceInDown"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col centered",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                                        children: [
                                            "  ",
                                            modalToast.title || "SUCCESS!"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: " text-dark flex flex-row centered",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "icofont-arrow-right animate-ping mr-2"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "text-red-800 animated flash",
                                                dangerouslySetInnerHTML: {
                                                    __html: modalToast.message
                                                }
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex justify-center mt-10"
                            })
                        ]
                    })
                ]
            })
        })
    });
};

;// CONCATENATED MODULE: ./src/redux/actions/BtnBuyPackage.js





//--- redux store---------------------------------------




//--------------------------------------
function BtnBuyPackage_BtnActivateBinary() {
    const router = (0,router_.useRouter)();
    const { 0: spinner , 1: setSpinner  } = (0,external_react_.useState)(false);
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { userid , token  } = (0,external_react_redux_.useSelector)((state)=>state.AuthReducer
    );
    const { selectedPackage  } = (0,external_react_redux_.useSelector)((state)=>state.PackageReducer
    );
    const handleBuyPackage = async ()=>{
        setSpinner(true);
        console.log(selectedPackage);
        console.log(selectedPackage.pid);
        const data1 = {
            pid: selectedPackage.pid,
            userid
        };
        console.log(data1);
        const URL = "https://api.fivefortunefx.com";
        return external_axios_default()({
            url: `${URL}/package/buy-package`,
            method: "POST",
            data: data1,
            "headers": {
                "Authorization": token,
                accept: "application/json",
                "content-type": "application/json"
            }
        }).then(async (response)=>{
            const data = response.data;
            if (data.isSuccess) {
                setSpinner(false);
                console.log(response.data.e_wallet);
                dispatch((0,AuthReducer/* setEWallet */.Ze)(response.data.e_wallet));
                dispatch((0,AuthReducer/* setIsActive */.WA)(1));
                dispatch((0,ModalReducer/* setModalConfirmBuyPackage */.Ez)(false));
                dispatch((0,SoundReducer/* setPlaySound */.Pl)("success"));
                return dispatch((0,ModalReducer/* setModalToast */.WA)({
                    type: response.data.type,
                    title: response.data.title,
                    message: response.data.message
                }));
            } else {
                setSpinner(false);
                dispatch((0,ModalReducer/* setModalConfirmBuyPackage */.Ez)(false));
                return dispatch((0,ModalReducer/* setModalToast */.WA)({
                    type: "error",
                    title: "Activation Fail!",
                    message: response.data.message
                }));
            // return dispatch(setError({ path: response.data.path, message: response.data.message }))
            }
            setSpinner(false);
        }).catch(function(error) {
            setSpinner(false);
            console.log(error);
            return dispatch((0,ModalReducer/* setModalMessage */.Zu)({
                type: "danger",
                title: "Network Error!",
                message: "Please check your Internet connection"
            }));
        });
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: spinner ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
            onClick: handleBuyPackage,
            className: "_btn_submit_blue border-2 border-gray-300",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                    style: {
                        maxWidth: 40
                    },
                    role: "status",
                    className: "mr-4 inline w-4 h-4 text-gray-200 dark:text-gray-300 animate-spin fill-blue-600",
                    viewBox: "0 0 100 101",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            d: "M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z",
                            fill: "currentColor"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            d: "M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z",
                            fill: "currentFill"
                        })
                    ]
                }),
                "processing....."
            ]
        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
            onClick: handleBuyPackage,
            className: "_btn_submit_blue border-2 border-gray-300",
            children: [
                "Yes Confirm  ",
                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                    className: "icofont-rounded-double-right ml-2 text-lg"
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./src/redux/actions/BtnAddMorePackage.js





//--- redux store---------------------------------------




//--------------------------------------
function BtnAddMorePackage_BtnActivateBinary() {
    const router = (0,router_.useRouter)();
    const { 0: spinner , 1: setSpinner  } = (0,external_react_.useState)(false);
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { userid , token  } = (0,external_react_redux_.useSelector)((state)=>state.AuthReducer
    );
    const { selectedPackage  } = (0,external_react_redux_.useSelector)((state)=>state.PackageReducer
    );
    const handleBuyPackage = async ()=>{
        setSpinner(true);
        console.log(selectedPackage);
        console.log(selectedPackage.pid);
        const data1 = {
            pid: selectedPackage.pid,
            userid
        };
        console.log(data1);
        const URL = "https://api.fivefortunefx.com";
        return external_axios_default()({
            url: `${URL}/package/add-package`,
            method: "POST",
            data: data1,
            "headers": {
                "Authorization": token,
                accept: "application/json",
                "content-type": "application/json"
            }
        }).then(async (response)=>{
            const data = response.data;
            if (data.isSuccess) {
                setSpinner(false);
                dispatch((0,AuthReducer/* setRWallet */.ql)(response.data.wallet.r_wallet));
                dispatch((0,ModalReducer/* setModalConfirmBuyPackage */.Ez)(false));
                dispatch((0,SoundReducer/* setPlaySound */.Pl)("success"));
                return dispatch((0,ModalReducer/* setModalToast */.WA)({
                    type: response.data.type,
                    title: response.data.title,
                    message: response.data.message
                }));
            } else {
                setSpinner(false);
                dispatch((0,ModalReducer/* setModalConfirmBuyPackage */.Ez)(false));
                return dispatch((0,ModalReducer/* setModalToast */.WA)({
                    type: "error",
                    title: "Activation Fail!",
                    message: response.data.message
                }));
            // return dispatch(setError({ path: response.data.path, message: response.data.message }))
            }
            setSpinner(false);
        }).catch(function(error) {
            setSpinner(false);
            console.log(error);
            return dispatch((0,ModalReducer/* setModalMessage */.Zu)({
                type: "danger",
                title: "Network Error!",
                message: "Please check your Internet connection"
            }));
        });
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: spinner ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
            onClick: handleBuyPackage,
            className: "_btn_submit_blue border-2 border-gray-300",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                    style: {
                        maxWidth: 40
                    },
                    role: "status",
                    className: "mr-4 inline w-4 h-4 text-gray-200 dark:text-gray-300 animate-spin fill-blue-600",
                    viewBox: "0 0 100 101",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            d: "M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z",
                            fill: "currentColor"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            d: "M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z",
                            fill: "currentFill"
                        })
                    ]
                }),
                "processing....."
            ]
        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
            onClick: handleBuyPackage,
            className: "_btn_submit_blue border-2 border-gray-300",
            children: [
                "Yes Add More  ",
                /*#__PURE__*/ jsx_runtime_.jsx("i", {
                    className: "icofont-rounded-double-right ml-2 text-lg"
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./src/components/modal/ModalConfirmBuyPackage.js


//import Link from 'next/link'



//---- REDUX STORE ---------------------


//import { setBuyEpinSpinner } from 'redux/reducers/LoaderReducer'
//import { setContinueBuy } from 'redux/reducers/EpinReducer'
//--------------------------------------
function ModalConfirmBuyPins() {
    const outsideRef = (0,external_react_.useRef)();
    const overlayRef = (0,external_react_.useRef)();
    const router = (0,router_.useRouter)();
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { 0: continueLoader , 1: setContinueLoader  } = (0,external_react_.useState)(false);
    const { modalConfirmBuyPackage  } = (0,external_react_redux_.useSelector)((state)=>state.ModalReducer
    );
    const { isLogin , isActive ,  } = (0,external_react_redux_.useSelector)((state)=>state.AuthReducer
    );
    (0,external_react_.useEffect)(()=>{
        if (modalConfirmBuyPackage) {
            setTimeout(()=>{
                const checkIfClickedOutside = (e)=>{
                    if (outsideRef.current && !outsideRef.current.contains(e.target)) {
                        document.body.classList.remove("overflow-hidden");
                        handleCloseModal();
                    }
                };
                document.addEventListener("click", checkIfClickedOutside);
                return ()=>{
                    document.removeEventListener("click", checkIfClickedOutside);
                };
            }, 500);
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        modalConfirmBuyPackage
    ]);
    const handleCloseModal = ()=>{
        if (overlayRef.current) {
            overlayRef.current.classList.add("zoomOut");
        }
        setTimeout(()=>{
            dispatch((0,ModalReducer/* setModalConfirmBuyPackage */.Ez)(false));
            document.body.classList.remove("overflow-hidden");
        }, 500);
    };
    const handleContinueBinary = ()=>{
        dispatch((0,ModalReducer/* setModalConfirmBuyPackage */.Ez)(false));
    // continue to buy-epins.js to process buy epins
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "fixed w-full inset-0 overflow-hidden flex justify-center items-center animated",
            style: {
                zIndex: 100
            },
            ref: overlayRef,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "_gradient_slate relative border-2 shadow-2xl mx-auto rounded-xl z-50 overflow-y-auto w-96 animated zoomIn",
                ref: outsideRef,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                        className: "icofont-close-circled absolute top-1 right-2 text-3xl text-orange-400 cursor-pointer",
                        onClick: handleCloseModal
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "modal-content py-4 px-4",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h5", {
                                className: "text-gray-100 uppercase font-semibold text-white",
                                children: [
                                    "Confirm to ",
                                    isActive ? "Add More Package" : "buy package",
                                    "?"
                                ]
                            }),
                            isActive ? /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-white",
                                children: "Buy Package Using only R Wallet"
                            }) : /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-white",
                                children: "Buy Package Using E Wallet"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex justify-between mt-4",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        onClick: handleCloseModal,
                                        className: "_btn_submit_red flex centered",
                                        children: "Cancel"
                                    }),
                                    isActive ? /*#__PURE__*/ jsx_runtime_.jsx(BtnAddMorePackage_BtnActivateBinary, {}) : /*#__PURE__*/ jsx_runtime_.jsx(BtnBuyPackage_BtnActivateBinary, {})
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
};

;// CONCATENATED MODULE: ./src/redux/reducers/DrawerReducer.js

const DrawerReducer_initialState = {
    dropdownOpen: false
};
const drawerSlice = (0,toolkit_.createSlice)({
    name: "drawer",
    initialState: DrawerReducer_initialState,
    reducers: {
        setdropdownOpen: (state, action)=>{
            state.dropdownOpen = action.payload;
        },
        reseDrawer: ()=>DrawerReducer_initialState
    }
});
const { reseDrawer , setdropdownOpen  } = drawerSlice.actions;
/* harmony default export */ const DrawerReducer = (drawerSlice.reducer);

;// CONCATENATED MODULE: ./src/layout/LEftSidebar.js





//---- REDUX STORE ---------------------






//--------------------------------------
function LEftSidebar_Home() {
    const dispatch = (0,external_react_redux_.useDispatch)();
    const router = (0,router_.useRouter)();
    const { rightSidebar , leftSidebar  } = (0,external_react_redux_.useSelector)((state)=>state.MainmenuReducer
    );
    const { isLogin  } = (0,external_react_redux_.useSelector)((state)=>state.AuthReducer
    );
    const { allowSound  } = (0,external_react_redux_.useSelector)((state)=>state.SettingReducer
    );
    const { dropdownOpen  } = (0,external_react_redux_.useSelector)((state)=>state.DrawerReducer
    );
    const handleHomepage = ()=>{
        dispatch((0,MainmenuReducer/* setLeftSidebar */.Gs)(false));
        router.push("/");
    };
    const handleClickMenu = (link)=>{
        dispatch(setShowLogin(true));
        dispatch((0,MainmenuReducer/* setLeftSidebar */.Gs)(false));
        dispatch((0,SoundReducer/* setPlaySound */.Pl)("click"));
        if (!isLogin) {
            dispatch((0,MainmenuReducer/* setLoginSidebar */.gu)(true));
            dispatch(setShowLogin(true));
        } else {
            router.push(link);
        }
    };
    const handleSound = ()=>{
        if (allowSound) {
            dispatch((0,SettingReducer/* setAllowSound */.qr)(false));
        } else {
            dispatch((0,SoundReducer/* setPlaySound */.Pl)("good"));
            dispatch((0,SettingReducer/* setAllowSound */.qr)(true));
        }
    };
    const handleDropdownOpen = (no)=>{
        dispatch((0,SoundReducer/* setPlaySound */.Pl)("click"));
        if (dropdownOpen === no) {
            dispatch(setdropdownOpen(0));
        } else {
            dispatch(setdropdownOpen(no));
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            class: `fixed bg-red-900 overflow-auto pb-20  top-0 left-0 z-40 h-screen p-4 overflow-y-auto transition-transform  ${!leftSidebar && "-translate-x-full"} bg-white w-96 mt-24 dark:bg-gray-800`,
            tabindex: "-1",
            "aria-labelledby": "drawer-navigation-label",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                    class: "text-base font-semibold text-white uppercase dark:text-gray-400",
                    children: "Menu"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    class: "py-4 mb-20 h-screen pb-20 pt-10 border-t",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        class: "space-y-2 font-medium text-lg text-white",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                    onClick: handleHomepage,
                                    class: "bg-gray-900/30 flex w-full items-center p-4 text-white rounded-lg dark:text-white group",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "icofont-monitor mr-4 text-2xl"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            class: "ms-3",
                                            children: "Main Page"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                    onClick: ()=>handleClickMenu("/users")
                                    ,
                                    class: "bg-gray-900/30 flex w-full items-center p-4 text-white rounded-lg dark:text-white group",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "icofont-pie-chart text-purple-400 mr-4 text-2xl"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            class: "ms-3",
                                            children: "Dashboard"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                        onClick: ()=>handleDropdownOpen(1)
                                        ,
                                        class: "bg-gray-900/30 flex items-center w-full p-4 text-base text-white transition duration-75 rounded-lg group dark:text-white ",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                class: "flex-shrink-0 w-5 h-5 text-white transition duration-75 dark:text-gray-400 group-hover: text-white dark:group-hover:text-white",
                                                "aria-hidden": "true",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                fill: "currentColor",
                                                viewBox: "0 0 18 18",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    d: "M6.143 0H1.857A1.857 1.857 0 0 0 0 1.857v4.286C0 7.169.831 8 1.857 8h4.286A1.857 1.857 0 0 0 8 6.143V1.857A1.857 1.857 0 0 0 6.143 0Zm10 0h-4.286A1.857 1.857 0 0 0 10 1.857v4.286C10 7.169 10.831 8 11.857 8h4.286A1.857 1.857 0 0 0 18 6.143V1.857A1.857 1.857 0 0 0 16.143 0Zm-10 10H1.857A1.857 1.857 0 0 0 0 11.857v4.286C0 17.169.831 18 1.857 18h4.286A1.857 1.857 0 0 0 8 16.143v-4.286A1.857 1.857 0 0 0 6.143 10Zm10 0h-4.286A1.857 1.857 0 0 0 10 11.857v4.286c0 1.026.831 1.857 1.857 1.857h4.286A1.857 1.857 0 0 0 18 16.143v-4.286A1.857 1.857 0 0 0 16.143 10Z"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                class: "flex-1 ms-3 text-left rtl:text-right whitespace-nowrap ml-4 text-white",
                                                children: "PACKAGES"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                class: `w-3 h-3 ${dropdownOpen === 1 ? "" : "-rotate-90"} `,
                                                "aria-hidden": "true",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                fill: "none",
                                                viewBox: "0 0 10 6",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    stroke: "currentColor",
                                                    "stroke-linecap": "round",
                                                    "stroke-linejoin": "round",
                                                    "stroke-width": "2",
                                                    d: "m1 1 4 4 4-4"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        class: ` py-2 space-y-6 py-6 bg-gray-700/30 animated fadeIn ${dropdownOpen === 1 ? "" : "hidden"} `,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                    onClick: ()=>handleClickMenu("/users/packages")
                                                    ,
                                                    class: "ml-6",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            class: "icofont-arrow-right"
                                                        }),
                                                        "Packages"
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                    onClick: ()=>handleClickMenu("/users/my-packages")
                                                    ,
                                                    class: "ml-6",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            class: "icofont-arrow-right"
                                                        }),
                                                        "My Package"
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                        onClick: ()=>handleDropdownOpen(2)
                                        ,
                                        class: "bg-gray-900/30 flex items-center w-full p-4 text-base text-white transition duration-75 rounded-lg group dark:text-white ",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "icofont-electron text-red-300 text-2xl"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                class: "flex-1 ms-3 text-left rtl:text-right whitespace-nowrap ml-4 text-white",
                                                children: "TRANSACTIONS"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                class: `w-3 h-3 ${dropdownOpen === 2 ? "" : "-rotate-90"} `,
                                                "aria-hidden": "true",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                fill: "none",
                                                viewBox: "0 0 10 6",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    stroke: "currentColor",
                                                    "stroke-linecap": "round",
                                                    "stroke-linejoin": "round",
                                                    "stroke-width": "2",
                                                    d: "m1 1 4 4 4-4"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        class: `  py-2 space-y-6 py-6 bg-gray-700/30 animated fadeIn ${dropdownOpen === 2 ? "" : "hidden"} `,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                    onClick: ()=>handleClickMenu("/users/deposit")
                                                    ,
                                                    class: "ml-6 ",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            class: "icofont-arrow-right"
                                                        }),
                                                        "Deposit Wallet"
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                    onClick: ()=>handleClickMenu("/users/history-deposit")
                                                    ,
                                                    class: "ml-6 ",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            class: "icofont-arrow-right"
                                                        }),
                                                        "History Deposit Wallet"
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                    onClick: ()=>handleClickMenu("/users/wd-request")
                                                    ,
                                                    class: "ml-6 ",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            class: "icofont-arrow-right"
                                                        }),
                                                        "WD Request"
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                    onClick: ()=>handleClickMenu("/users/history-wd-request")
                                                    ,
                                                    class: "ml-6 ",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            class: "icofont-arrow-right"
                                                        }),
                                                        "History WD Request"
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                        onClick: ()=>handleDropdownOpen(3)
                                        ,
                                        class: "bg-gray-900/30 flex items-center w-full p-4 text-base text-white transition duration-75 rounded-lg group dark:text-white ",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                class: "icofont-coins text-2xl text-green-400"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                class: "flex-1 ms-3 text-left rtl:text-right whitespace-nowrap ml-4",
                                                children: "BONUS"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                class: "w-3 h-3",
                                                "aria-hidden": "true",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                fill: "none",
                                                viewBox: "0 0 10 6",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    stroke: "currentColor",
                                                    "stroke-linecap": "round",
                                                    "stroke-linejoin": "round",
                                                    "stroke-width": "2",
                                                    d: "m1 1 4 4 4-4"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        class: `py-2 space-y-6 py-6 bg-gray-700/30 animated fadeIn ${dropdownOpen === 3 ? "" : "hidden"} `,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                    onClick: ()=>handleClickMenu("/users/referrals")
                                                    ,
                                                    class: "ml-6",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            class: "icofont-users mr-4"
                                                        }),
                                                        "My Referrals"
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                    onClick: ()=>handleClickMenu("/users/refferals-bonus")
                                                    ,
                                                    class: "ml-6 ",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            class: "icofont-flora-flower text-2xl mr-4"
                                                        }),
                                                        "Referrals Bonus"
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                    onClick: ()=>handleClickMenu("/users/matching-bonus")
                                                    ,
                                                    class: "ml-6",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            class: "icofont-chart-flow text-2xl mr-4"
                                                        }),
                                                        "   Matching Bonus"
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                        onClick: ()=>handleDropdownOpen(4)
                                        ,
                                        class: "bg-gray-900/30 flex items-center w-full p-4 text-base text-white transition duration-75 rounded-lg group dark:text-white ",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                className: "icofont-gear text-2xl text-sky-400"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                class: "flex-1 ms-3 text-left rtl:text-right whitespace-nowrap ml-4",
                                                children: "SETTTINGS"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                                class: "w-3 h-3",
                                                "aria-hidden": "true",
                                                xmlns: "http://www.w3.org/2000/svg",
                                                fill: "none",
                                                viewBox: "0 0 10 6",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                                    stroke: "currentColor",
                                                    "stroke-linecap": "round",
                                                    "stroke-linejoin": "round",
                                                    "stroke-width": "2",
                                                    d: "m1 1 4 4 4-4"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                        class: `py-2 space-y-6 py-6 bg-gray-700/30 animated fadeIn ${dropdownOpen === 4 ? "" : "hidden"} `,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                    onClick: ()=>handleClickMenu("/users/change-password")
                                                    ,
                                                    class: "ml-6",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "icofont-lock text-2xl mr-1 text-yellow-300 hover:text-green-300"
                                                        }),
                                                        "Change Password"
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                    onClick: ()=>handleClickMenu("/users/change-email")
                                                    ,
                                                    class: "ml-6",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                            className: "icofont-email text-2xl mr-2 text-yellow-300 hover:text-green-300"
                                                        }),
                                                        "Change Eamil"
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    onClick: handleSound,
                                                    className: "cursor-pointer flex flex-row items-center h-10 pl-6 ",
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                                        className: "text-1xl",
                                                        children: [
                                                            allowSound ? /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "icofont-audio text-3xl mr-2 text-green-400 "
                                                            }) : /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "icofont-ui-mute text-3xl mr-2 text-yellow-400"
                                                            }),
                                                            " Sound Setting"
                                                        ]
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            isLogin && /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                    onClick: ()=>handleClickMenu("/logout")
                                    ,
                                    class: "flex items-center w-full p-2 text-base text-white transition duration-75 rounded-lg group dark:text-white ",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                            className: "icofont-logout text-2xl mr-1 text-yellow-300 hover:text-green-300"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            class: "flex-1 ms-3 text-left rtl:text-right whitespace-nowrap ml-4",
                                            children: "LOGOUT"
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./src/layout/MobileTopNavigation.js





const moment = __webpack_require__(2245);



//---- REDUX STORE ---------------------






//--------------------------------------
function MobileTopNavigation_TopNavigation() {
    const router = (0,router_.useRouter)();
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { isLogin , userID , token , username , fullname , toggleLogin  } = (0,external_react_redux_.useSelector)((state)=>state.AuthReducer
    );
    const { showLogin  } = (0,external_react_redux_.useSelector)((state)=>state.SidebarReducer
    );
    const { spinnerAtVisitor  } = (0,external_react_redux_.useSelector)((state)=>state.LoaderReducer
    );
    const { cofetty  } = (0,external_react_redux_.useSelector)((state)=>state.ModalReducer
    );
    const { modalMenuDrawer  } = (0,external_react_redux_.useSelector)((state)=>state.ModalReducer
    );
    const { loginSidebar , leftSidebar  } = (0,external_react_redux_.useSelector)((state)=>state.MainmenuReducer
    );
    const handleUserClick = ()=>{
        if (router.pathname !== "/users") {}
        setTimeout(()=>{
            router.push("/users");
        }, 1000);
    };
    const handleOpenDrawer = ()=>{
        dispatch((0,SoundReducer/* setPlaySound */.Pl)("click"));
        if (leftSidebar) {
            dispatch((0,MainmenuReducer/* setLeftSidebar */.Gs)(false));
        } else {
            dispatch((0,MainmenuReducer/* setLeftSidebar */.Gs)(true));
            dispatch((0,MainmenuReducer/* setLoginSidebar */.gu)(false));
        }
    };
    const handleToggle = ()=>{
        dispatch((0,FormReducer/* resetForm */.Fx)());
        dispatch((0,ErrorReducer/* resetErrors */.n2)());
        if (loginSidebar) {
            dispatch((0,MainmenuReducer/* setLoginSidebar */.gu)(false));
        } else {
            dispatch((0,MainmenuReducer/* setLoginSidebar */.gu)(true));
            dispatch((0,MainmenuReducer/* setLeftSidebar */.Gs)(false));
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(LEftSidebar_Home, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Home, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "bg-red-900 sticky top-0 z-10",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "bg-red-900 dark:bg-slate-900 rounded-br-[10%] rounded-bl-[10%] h-[100px] h-[90px] shadow-sm shadow-gray-200 w-full ",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
                        className: "rounded-bl-[40%] px-3 pt-2 flex flex-grow relative justify-between z-10 mx-auto ",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                className: "flex-initial w-[62px] h-[62px] p-2 cursor-pointer ",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    onClick: handleOpenDrawer,
                                    className: ` outline-none hover:outline-hidden transition duration-150 mt-2 animated backInLeft`,
                                    children: modalMenuDrawer ? /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        class: "icofont-arrow-left text-[40px] text-white animated fadeIn"
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                        width: "30px",
                                        role: "img",
                                        xmlns: "http://www.w3.org/2000/svg",
                                        viewBox: "0 0 448 512 ",
                                        className: leftSidebar ? "transition duration-150 -rotate-90" : "transition duration-150",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                            fill: "white",
                                            d: "M12 132h416c8.837 0 16-7.163 16-16V76c0-8.837-7.163-16-16-16H16C7.163 60 0 67.163 0 76v40c0 8.837 7.163 12 12 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 16 16 16zm0 160h416c8.837 0 16-7.163 16-16v-40c0-8.837-7.163-16-16-16H16c-8.837 0-16 7.163-16 16v40c0 8.837 7.163 12 12 12z"
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                onClick: ()=>router.push("/")
                                ,
                                className: "cursor-pointer flex centered w-[250px] mt-2 mr-6",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: "/assets/F5-logo.png",
                                    className: " animated fadeInDown w-3/2",
                                    alt: "logo"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "rounded-full w-[60px] h-[60px] flex flex-col centered items-center ",
                                children: !isLogin ? /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                    onClick: handleToggle,
                                    className: "flex justify-center text-sm text-white rounded-full hover:bg-blue-500 transition ease-in-out duration-300 py-1 border-4 border-gray-400 text-xl px-2",
                                    children: showLogin ? "LOGIN" : "REGISTER"
                                }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                        onClick: ()=>router.push("/users")
                                        ,
                                        className: "text-white",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: "/assets/img/avatar.webp",
                                                className: "rounded-full w-[40px]",
                                                alt: "users"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("small", {
                                                children: "Users"
                                            }),
                                            "   "
                                        ]
                                    })
                                })
                            })
                        ]
                    })
                })
            })
        ]
    });
};

;// CONCATENATED MODULE: ./src/redux/reducers/GeneralReducer.js

const GeneralReducer_initialState = {
    masterUser: "FX10001",
    domain: "https://fivefortunefx.com",
    title: "FIVEFORTUNE",
    desc: "FIVEFORTUNE COMMUNITY",
    currency: "M-Poin",
    crypto: "BUSD",
    width: false
};
const GeneralSlice = (0,toolkit_.createSlice)({
    name: "general",
    initialState: GeneralReducer_initialState,
    reducers: {
        setDomain: (state, action)=>{
            state.domain = action.payload;
        },
        setWidth: (state, action)=>{
            state.width = action.payload;
        }
    }
});
const { setDomain , setWidth  } = GeneralSlice.actions;
/* harmony default export */ const GeneralReducer = (GeneralSlice.reducer);

;// CONCATENATED MODULE: ./src/sound/PlaySound.js


//---- REDUX STORE ---------------------


//--------------------------------------
function PlaySound() {
    const soundError = (0,external_react_.useRef)(null);
    const soundClick = (0,external_react_.useRef)(null);
    const soundPling = (0,external_react_.useRef)(null);
    const soundVerified = (0,external_react_.useRef)(null);
    const soundTransfer = (0,external_react_.useRef)(null);
    const soundSuccess = (0,external_react_.useRef)(null);
    const soundLogin = (0,external_react_.useRef)(null);
    const soundGood = (0,external_react_.useRef)(null);
    const dispatch = (0,external_react_redux_.useDispatch)();
    const { allowSound  } = (0,external_react_redux_.useSelector)((state)=>state.SettingReducer
    );
    const { soundEffect  } = (0,external_react_redux_.useSelector)((state)=>state.SoundReducer
    );
    const playSound = ()=>{
        let elm;
        try {
            if (soundEffect === "error") {
                elm = soundError.current;
                elm.play();
            }
            if (soundEffect === "click") {
                elm = soundClick.current;
                elm.play();
            }
            if (soundEffect === "pling") {
                elm = soundPling.current;
                elm.play();
            }
            if (soundEffect === "verified") {
                elm = soundVerified.current;
                elm.play();
            }
            if (soundEffect === "transfer") {
                elm = soundTransfer.current;
                elm.play();
            }
            if (soundEffect === "success") {
                elm = soundSuccess.current;
                elm.play();
            }
            if (soundEffect === "login") {
                elm = soundLogin.current;
                elm.play();
            }
            if (soundEffect === "good") {
                elm = soundGood.current;
                elm.play();
            }
        } catch (error) {
            console.log(error);
        // return res.status(400).json({ isSuccess: 'fail', message: error })
        }
    };
    (0,external_react_.useEffect)(()=>{
        if (allowSound) {
            try {
                playSound();
            } catch (error) {
                console.log(error);
            // return res.status(400).json({ isSuccess: 'fail', message: error })
            }
            setTimeout(()=>{
                dispatch((0,SoundReducer/* setPlaySound */.Pl)(false));
            });
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        soundEffect,
        allowSound
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("audio", {
                ref: soundError,
                // controls
                src: "/sound/error.mp3",
                children: [
                    "Your browser does not support the",
                    /*#__PURE__*/ jsx_runtime_.jsx("code", {
                        children: "audio"
                    }),
                    " element."
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("audio", {
                ref: soundClick,
                // controls
                src: "/sound/beep.mp3",
                children: [
                    "Your browser does not support the",
                    /*#__PURE__*/ jsx_runtime_.jsx("code", {
                        children: "audio"
                    }),
                    " element."
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("audio", {
                ref: soundPling,
                src: "/sound/pling.mp3",
                children: [
                    "Your browser does not support the",
                    /*#__PURE__*/ jsx_runtime_.jsx("code", {
                        children: "audio"
                    }),
                    " element."
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("audio", {
                ref: soundVerified,
                src: "/sound/verified.mp3",
                children: [
                    "Your browser does not support the",
                    /*#__PURE__*/ jsx_runtime_.jsx("code", {
                        children: "audio"
                    }),
                    " element."
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("audio", {
                ref: soundTransfer,
                src: "/sound/transfer.mp3",
                children: [
                    "Your browser does not support the",
                    /*#__PURE__*/ jsx_runtime_.jsx("code", {
                        children: "audio"
                    }),
                    " element."
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("audio", {
                ref: soundSuccess,
                src: "/sound/success.mp3",
                children: [
                    "Your browser does not support the",
                    /*#__PURE__*/ jsx_runtime_.jsx("code", {
                        children: "audio"
                    }),
                    " element."
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("audio", {
                ref: soundLogin,
                src: "/sound/login.mp3",
                children: [
                    "Your browser does not support the",
                    /*#__PURE__*/ jsx_runtime_.jsx("code", {
                        children: "audio"
                    }),
                    " element."
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("audio", {
                ref: soundGood,
                src: "/sound/good.mp3",
                children: [
                    "Your browser does not support the",
                    /*#__PURE__*/ jsx_runtime_.jsx("code", {
                        children: "audio"
                    }),
                    " element."
                ]
            })
        ]
    });
};

;// CONCATENATED MODULE: ./src/layout/index.js


//import Link from 'next/link'










// import ModalLogin from "components/modal/ModalLogin";



//--- redux store---------------------------------------



//import { setAllowReloadUsers } from 'redux/reducers/UsersReducer'
//import HeaderBoard from "./HeaderBoard"
//-------------------------------------------------------
function MainLayout({ children  }) {
    const dispatch = (0,external_react_redux_.useDispatch)();
    const router = (0,router_.useRouter)();
    const { asPath , pathname  } = (0,router_.useRouter)();
    const path = pathname.substring(1, 6);
    const { width  } = (0,external_react_redux_.useSelector)((state)=>state.GeneralReducer
    );
    const { isLogin  } = (0,external_react_redux_.useSelector)((state)=>state.AuthReducer
    );
    const { mainSidebarOpen  } = (0,external_react_redux_.useSelector)((state)=>state.MainmenuReducer
    );
    const { modalMessage , modalToast , modalMenuDrawer , modalConfirmBuyPackage ,  } = (0,external_react_redux_.useSelector)((state)=>state.ModalReducer
    );
    const { rightSidebar  } = (0,external_react_redux_.useSelector)((state)=>state.MainmenuReducer
    );
    (0,external_react_.useEffect)(()=>{
        //width >761 && dispatch(setModalMenuDrawer(false))
        width < 1200 ? dispatch((0,MainmenuReducer/* setMainSidebarOpen */.Zd)(false)) : dispatch((0,MainmenuReducer/* setMainSidebarOpen */.Zd)(true));
    }, [
        width
    ]);
    (0,external_react_.useEffect)(()=>{
        dispatch(setWidth(window.innerWidth));
    // dispatch(setAllowReloadUsers(true)) 
    //document.documentElement.classList.add('dark');
    }, []);
    (0,external_react_.useEffect)(()=>{
        const handleResize = ()=>{
            dispatch(setWidth(window.innerWidth));
        };
        window.addEventListener("resize", handleResize);
        return ()=>{
            window.removeEventListener("resize", handleResize);
        };
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(PlaySound, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(BtnActivateBinary, {}),
            !isLogin && /*#__PURE__*/ jsx_runtime_.jsx(ReferralLink, {}),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                className: "w-full min-h-screen",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
                    className: isLogin ? width > 760 ? "text-slate-900 dark:text-white w-full mx-auto  bg-slate-700 bg-fixed bg-cover max-w-md md:max-w-full  z-1  bg-[url('/assets/img/bg/user-bg.webp')]" : "text-slate-900 dark:text-white w-full mx-auto  bg-slate-800 bg-fixed bg-cover max-w-md md:max-w-full  z-1 " : "text-slate-900 dark:text-white w-full mx-auto  bg-slate-700 bg-fixed bg-cover max-w-md md:max-w-full  z-1 bg-slate-900",
                    children: [
                        path == "users" ? width > 760 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(TopNavigation, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(FirebaseSidebar, {})
                            ]
                        }) : /*#__PURE__*/ jsx_runtime_.jsx(MobileTopNavigation_TopNavigation, {}) : width > 760 ? /*#__PURE__*/ jsx_runtime_.jsx(MainHeader, {}) : /*#__PURE__*/ jsx_runtime_.jsx(MobileTopNavigation_TopNavigation, {}),
                        path == "users" && width > 760 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: mainSidebarOpen ? "ml-64   " : "ml-16  ",
                            children: [
                                children,
                                /*#__PURE__*/ jsx_runtime_.jsx(MainFooter, {})
                            ]
                        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                children,
                                /*#__PURE__*/ jsx_runtime_.jsx(MainFooter, {})
                            ]
                        })
                    ]
                })
            }),
            modalMessage && /*#__PURE__*/ jsx_runtime_.jsx(ModalMessage, {}),
            modalToast && /*#__PURE__*/ jsx_runtime_.jsx(ModalToast_ModalMessage, {}),
            modalMenuDrawer && /*#__PURE__*/ jsx_runtime_.jsx(ModalMenuDrawer, {}),
            modalConfirmBuyPackage && /*#__PURE__*/ jsx_runtime_.jsx(ModalConfirmBuyPins, {})
        ]
    });
};

;// CONCATENATED MODULE: external "redux-persist/lib/storage/createWebStorage"
const createWebStorage_namespaceObject = require("redux-persist/lib/storage/createWebStorage");
;// CONCATENATED MODULE: ./src/redux/storage.js

const createNoopStorage = ()=>{
    return {
        getItem (_key) {
            return Promise.resolve(null);
        },
        setItem (_key, value) {
            return Promise.resolve(value);
        },
        removeItem (_key) {
            return Promise.resolve();
        }
    };
};
const storage =  false ? 0 : createNoopStorage();
/* harmony default export */ const redux_storage = (storage);

;// CONCATENATED MODULE: external "redux"
const external_redux_namespaceObject = require("redux");
;// CONCATENATED MODULE: external "redux-thunk"
const external_redux_thunk_namespaceObject = require("redux-thunk");
var external_redux_thunk_default = /*#__PURE__*/__webpack_require__.n(external_redux_thunk_namespaceObject);
;// CONCATENATED MODULE: external "redux-persist"
const external_redux_persist_namespaceObject = require("redux-persist");
;// CONCATENATED MODULE: ./src/redux/reducers/PersistReducer.js

const PersistReducer_initialState = {
    clockSize: 250,
    // allowSound: false,
    allowNewJoinPopup: true,
    newUserJoin: false,
    investmentPackage: false
};
const PersistSlice = (0,toolkit_.createSlice)({
    name: "persist",
    initialState: PersistReducer_initialState,
    reducers: {
        // setAllowSound: (state, action) => {
        //     state.allowSound = action.payload
        // },
        setNewUserJoin: (state, action)=>{
            state.newUserJoin = action.payload;
        },
        setClockSize: (state, action)=>{
            state.clockSize = action.payload;
        },
        setAllowNewJoinPopup: (state, action)=>{
            state.allowNewJoinPopup = action.payload // used already
            ;
        },
        setInvestmentPackage: (state, action)=>{
            state.investmentPackage = action.payload;
        },
        resetPersist: ()=>PersistReducer_initialState
    }
});
const { resetPersist , setInvestmentPackage , setNewUserJoin , setClockSize  } = PersistSlice.actions;
/* harmony default export */ const PersistReducer = (PersistSlice.reducer);

// EXTERNAL MODULE: ./src/redux/reducers/StatementReducer.js
var StatementReducer = __webpack_require__(6111);
// EXTERNAL MODULE: ./src/redux/reducers/MatchingReducer.js
var MatchingReducer = __webpack_require__(2424);
// EXTERNAL MODULE: ./src/redux/reducers/AffiliateReducer.js
var AffiliateReducer = __webpack_require__(1490);
// EXTERNAL MODULE: ./src/redux/reducers/HistoryReducer.js
var HistoryReducer = __webpack_require__(4088);
;// CONCATENATED MODULE: ./src/redux/store.js

//import storage from 'redux-persist/lib/storage' // use in production is ok
 // prevent console waring message on development























const rootReducer = (0,external_redux_namespaceObject.combineReducers)({
    AuthReducer: AuthReducer/* default */.ZP,
    AffiliateReducer: AffiliateReducer/* default */.ZP,
    ConstantReducer: ConstantReducer,
    DrawerReducer: DrawerReducer,
    ErrorReducer: ErrorReducer/* default */.ZP,
    FormReducer: FormReducer/* default */.ZP,
    GeneralReducer: GeneralReducer,
    HistoryReducer: HistoryReducer/* default */.ZP,
    LoaderReducer: LoaderReducer/* default */.ZP,
    MainmenuReducer: MainmenuReducer/* default */.ZP,
    ModalReducer: ModalReducer/* default */.ZP,
    MatchingReducer: MatchingReducer/* default */.ZP,
    PersistReducer: PersistReducer,
    PackageReducer: PackageReducer/* default */.ZP,
    ReferralReducer: ReferralReducer/* default */.ZP,
    SoundReducer: SoundReducer/* default */.ZP,
    SettingReducer: SettingReducer/* default */.ZP,
    SidebarReducer: SidebarReducer,
    UsersReducer: UsersReducer,
    SettingReducer: SettingReducer/* default */.ZP,
    StatementReducer: StatementReducer/* default */.ZP
});
const persistConfig = {
    key: "root",
    storage: redux_storage,
    // whitelist: [],
    whitelist: [
        "AuthReducer",
        "SettingReducer",
        "ConstantReducer"
    ] //"PersistReducer"
};
const persistedReducer = (0,external_redux_persist_namespaceObject.persistReducer)(persistConfig, rootReducer);
const store = (0,toolkit_.configureStore)({
    reducer: persistedReducer,
    //  devTools: process.env.NODE_ENV !== 'production',
    middleware: [
        (external_redux_thunk_default())
    ]
});
const persistor = (0,external_redux_persist_namespaceObject.persistStore)(store);


;// CONCATENATED MODULE: external "redux-persist/integration/react"
const react_namespaceObject = require("redux-persist/integration/react");
;// CONCATENATED MODULE: external "metamask-react"
const external_metamask_react_namespaceObject = require("metamask-react");
;// CONCATENATED MODULE: ./src/pages/_app.js







//import '../../styles/products.css'





function MyApp({ Component , pageProps , router  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(external_metamask_react_namespaceObject.MetaMaskProvider, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_redux_.Provider, {
            store: store,
            children: /*#__PURE__*/ jsx_runtime_.jsx(react_namespaceObject.PersistGate, {
                loading: null,
                persistor: persistor,
                children: /*#__PURE__*/ jsx_runtime_.jsx(MainLayout, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                        ...pageProps
                    })
                })
            })
        })
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 4088:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Iz": () => (/* binding */ setWDCashTx),
/* harmony export */   "P$": () => (/* binding */ setWDCashArray),
/* harmony export */   "Ve": () => (/* binding */ setWDCashTotal),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "kE": () => (/* binding */ setTotalWDPaid)
/* harmony export */ });
/* unused harmony exports historySlice, resetHistory */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    WDCashArray: false,
    WDCashTx: false,
    WDCashTotal: false,
    totalWDPaid: false
};
const historySlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "history",
    initialState,
    reducers: {
        setWDCashArray: (state, action)=>{
            state.WDCashArray = action.payload;
        },
        setWDCashTx: (state, action)=>{
            state.WDCashTx = action.payload;
        },
        setWDCashTotal: (state, action)=>{
            state.WDCashTotal = action.payload;
        },
        setTotalWDPaid: (state, action)=>{
            state.totalWDPaid = action.payload;
        },
        resetHistory: ()=>initialState
    }
});
const { resetHistory , setWDCashArray , setWDCashTx , setWDCashTotal , setTotalWDPaid  } = historySlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (historySlice.reducer);


/***/ }),

/***/ 2424:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "BI": () => (/* binding */ setTotalTx),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "o": () => (/* binding */ setMyMatchingBonusArray),
/* harmony export */   "zR": () => (/* binding */ setTotalMatchingBonus)
/* harmony export */ });
/* unused harmony exports RefLinkSlice, resetRefLink */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    myMatchingBonusArray: false,
    totalMatchingBonus: false,
    totalTx: false
};
const RefLinkSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "refs",
    initialState,
    reducers: {
        setMyMatchingBonusArray: (state, action)=>{
            state.myMatchingBonusArray = action.payload;
        },
        setTotalMatchingBonus: (state, action)=>{
            state.totalMatchingBonus = action.payload;
        },
        setTotalTx: (state, action)=>{
            state.totalTx = action.payload;
        },
        resetRefLink: ()=>initialState
    }
});
const { resetRefLink , setMyMatchingBonusArray , setTotalMatchingBonus , setTotalTx  } = RefLinkSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RefLinkSlice.reducer);


/***/ }),

/***/ 2686:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ID": () => (/* binding */ setTotalRefBonus),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "Zr": () => (/* binding */ setMyRefBonusArray),
/* harmony export */   "rt": () => (/* binding */ setRefLink)
/* harmony export */ });
/* unused harmony exports RefLinkSlice, resetRefLink */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    // master: 'FX10001', // default
    // refLink: 'FX10001' // default
    masterRef: "FX10001",
    refLink: "FX10001",
    myRefBonusArray: false,
    totalRefBonus: false
};
const RefLinkSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "refs",
    initialState,
    reducers: {
        setRefLink: (state, action)=>{
            state.refLink = action.payload;
        },
        setMyRefBonusArray: (state, action)=>{
            state.myRefBonusArray = action.payload;
        },
        setTotalRefBonus: (state, action)=>{
            state.totalRefBonus = action.payload;
        },
        resetRefLink: ()=>initialState
    }
});
const { resetRefLink , setRefLink , setMyRefBonusArray , setTotalRefBonus  } = RefLinkSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RefLinkSlice.reducer);


/***/ }),

/***/ 8475:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Pl": () => (/* binding */ setPlaySound),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports ErrorSlice, resetSound */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    soundEffect: false
};
const ErrorSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "sound",
    initialState,
    reducers: {
        setPlaySound: (state, action)=>{
            state.soundEffect = action.payload;
        },
        resetSound: ()=>initialState
    }
});
const { resetSound , setPlaySound  } = ErrorSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ErrorSlice.reducer);


/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 2245:
/***/ ((module) => {

module.exports = require("moment");

/***/ }),

/***/ 562:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [895,664,152,536,719,126,956,111,847,772,861,490], () => (__webpack_exec__(173)));
module.exports = __webpack_exports__;

})();