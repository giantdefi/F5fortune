"use strict";
exports.id = 126;
exports.ids = [126];
exports.modules = {

/***/ 3126:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A2": () => (/* binding */ setSelectedPackName),
/* harmony export */   "UJ": () => (/* binding */ setAdmin_packages),
/* harmony export */   "Ui": () => (/* binding */ setDetailPackage),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "br": () => (/* binding */ resetPackage),
/* harmony export */   "fq": () => (/* binding */ setSelectedPackValue),
/* harmony export */   "h4": () => (/* binding */ setSelectedPackage),
/* harmony export */   "mq": () => (/* binding */ setMypackages),
/* harmony export */   "nO": () => (/* binding */ setSelectedActPackID),
/* harmony export */   "zK": () => (/* binding */ setWDAmounts)
/* harmony export */ });
/* unused harmony export packageSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    admin_packages: false,
    selectedPackage: false,
    myPacakges: false,
    detailPackage: false,
    selectedActPackID: false,
    selectedPackName: false,
    selectedPackValue: false,
    wdAmmounts: false
};
const packageSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: " packages",
    initialState,
    reducers: {
        setAdmin_packages: (state, action)=>{
            state.admin_packages = action.payload;
        },
        setSelectedPackage: (state, action)=>{
            state.selectedPackage = action.payload;
        },
        setMypackages: (state, action)=>{
            state.myPacakges = action.payload;
        },
        setDetailPackage: (state, action)=>{
            state.detailPackage = action.payload;
        },
        setSelectedActPackID: (state, action)=>{
            state.selectedActPackID = action.payload;
        },
        setSelectedPackName: (state, action)=>{
            state.selectedPackName = action.payload;
        },
        setWDAmounts: (state, action)=>{
            state.wdAmmounts = action.payload;
        },
        setSelectedPackValue: (state, action)=>{
            state.selectedPackValue = action.payload;
        },
        resetPackage: ()=>initialState
    }
});
const { resetPackage , setAdmin_packages , setSelectedPackage , setMypackages , setDetailPackage , setSelectedActPackID , setSelectedPackName , setWDAmounts , setSelectedPackValue  } = packageSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (packageSlice.reducer);


/***/ })

};
;