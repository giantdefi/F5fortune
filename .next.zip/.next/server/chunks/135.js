"use strict";
exports.id = 135;
exports.ids = [135];
exports.modules = {

/***/ 329:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ WDAmount)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var redux_reducers_FormReducer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(915);
/* harmony import */ var redux_reducers_ErrorReducer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2009);
/* harmony import */ var redux_reducers_SoundReducer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8475);


//--- redux store---------------------------------------




//-------------------------------------------------------
function WDAmount() {
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    // redux store
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useDispatch)();
    const { wdWalletAmount , walletAddr  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state.FormReducer
    );
    const { formError  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state.ErrorReducer
    );
    const { e_wallet  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_2__.useSelector)((state)=>state.AuthReducer
    );
    // handle on input value change
    const handleChange = (e)=>{
        dispatch((0,redux_reducers_ErrorReducer__WEBPACK_IMPORTED_MODULE_4__/* .setError */ .sT)(false));
        const { name , value  } = e.target;
        const re = /^[0-9]*\.?[0-9]*$/;
        if (re.test(value)) {
            if (value.length <= 6) {
                dispatch((0,redux_reducers_FormReducer__WEBPACK_IMPORTED_MODULE_3__/* .setWDWalletAmount */ .Wb)(value));
            }
            if (value > e_wallet) {
                dispatch((0,redux_reducers_SoundReducer__WEBPACK_IMPORTED_MODULE_5__/* .setPlaySound */ .Pl)("error"));
                return dispatch((0,redux_reducers_ErrorReducer__WEBPACK_IMPORTED_MODULE_4__/* .setError */ .sT)({
                    path: "wdWalletAmount",
                    message: "Exceed E Wallet balance!"
                }));
            }
        }
    };
    const handleMaxBalance = ()=>{
        dispatch((0,redux_reducers_ErrorReducer__WEBPACK_IMPORTED_MODULE_4__/* .setError */ .sT)(false));
        dispatch((0,redux_reducers_SoundReducer__WEBPACK_IMPORTED_MODULE_5__/* .setPlaySound */ .Pl)("pling"));
        dispatch((0,redux_reducers_FormReducer__WEBPACK_IMPORTED_MODULE_3__/* .setWDWalletAmount */ .Wb)(Math.floor(e_wallet)));
    };
    const handleMaxReset = ()=>{
        dispatch((0,redux_reducers_ErrorReducer__WEBPACK_IMPORTED_MODULE_4__/* .setError */ .sT)(false));
        dispatch((0,redux_reducers_SoundReducer__WEBPACK_IMPORTED_MODULE_5__/* .setPlaySound */ .Pl)("click"));
        dispatch((0,redux_reducers_FormReducer__WEBPACK_IMPORTED_MODULE_3__/* .setWDWalletAmount */ .Wb)(0));
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-full px-4 mt-5",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "relative w-full mb-3",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex justify-between mb-2 text-white",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "mb-2 text-sm text-white",
                                children: "WD EWallet Amount"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex justify-between gap-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        onClick: handleMaxBalance,
                                        className: "_gradient_gold mb-2 text-sm border px-4 rounded-sm ",
                                        children: " MAX "
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        onClick: handleMaxReset,
                                        className: "mb-2 text-sm border px-2 rounded-sm",
                                        children: " Reset "
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        type: "text",
                        className: " bg-gray-800 w-full text-white border border-gray-500 rounded-md py-2 px-3",
                        ref: inputRef,
                        name: "wdWalletAmount",
                        value: wdWalletAmount || "",
                        onChange: handleChange
                    }),
                    formError && formError.path === "wdWalletAmount" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                        className: "text-yellow-300 ml-2 mt-2 text-sm",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                className: "icofont-arrow-right animate-ping mr-2"
                            }),
                            formError.message
                        ]
                    }) : null
                ]
            })
        })
    });
};


/***/ }),

/***/ 6495:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ WalletAddress)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var redux_reducers_FormReducer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(915);
/* harmony import */ var redux_reducers_ErrorReducer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2009);




//--- redux store---------------------------------------



//-------------------------------------------------------
function WalletAddress() {
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    // redux store
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useDispatch)();
    const { walletAddr  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.FormReducer
    );
    const { formError  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useSelector)((state)=>state.ErrorReducer
    );
    // handle on input value change
    const handleChange = (e)=>{
        dispatch((0,redux_reducers_ErrorReducer__WEBPACK_IMPORTED_MODULE_6__/* .setError */ .sT)(false));
        //  dispatch(setShowCaptcha(false))
        const { name , value  } = e.target;
        if (value.length <= 100) {
            dispatch((0,redux_reducers_FormReducer__WEBPACK_IMPORTED_MODULE_5__/* .setWDCryptoAddress */ ._X)(value));
        }
    };
    // scroll to top and focus
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (formError && formError.path === "wdCryptoAddress") {
        //  inputRef.current.focus()
        // inputRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' }) // make it on center of the screen
        //  
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        formError
    ]);
    //  console.log(destData)
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-full px-4 mt-5",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full mt-5",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "mb-2 text-white",
                        children: " Your USDT Wallet address :"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                    type: "text",
                                    className: " bg-gray-800 w-full text-white border border-gray-500 rounded-md py-2 px-3",
                                    ref: inputRef,
                                    name: "walletAddr",
                                    value: walletAddr || "",
                                    onChange: handleChange
                                })
                            }),
                            formError && formError.path === "walletAddr" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                className: "text-yellow-300 ml-2 text-sm mt-1",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                        className: "icofont-arrow-right animate-ping mr-2"
                                    }),
                                    formError.message
                                ]
                            }) : null
                        ]
                    })
                ]
            })
        })
    });
};


/***/ })

};
;