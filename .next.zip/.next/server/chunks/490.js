"use strict";
exports.id = 490;
exports.ids = [490];
exports.modules = {

/***/ 1490:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ew": () => (/* binding */ setCountMyDownlines),
/* harmony export */   "Rw": () => (/* binding */ setMyDirestReferrals),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "tK": () => (/* binding */ setGetUsername),
/* harmony export */   "vy": () => (/* binding */ setMyDownlinesArray)
/* harmony export */ });
/* unused harmony exports AffiliateSlice, resetAffiliate, setMyDownlineLevel, setMyUpline, setPreviousUser */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    countMyDownline: false,
    myDownlinesArray: false,
    myDownlineLevel: false,
    getUsername: false,
    previousUser: false,
    myDirestReferrals: false
};
const AffiliateSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "affiliate",
    initialState,
    reducers: {
        setCountMyDownlines: (state, action)=>{
            state.countMyDownline = action.payload;
        },
        setMyDownlinesArray: (state, action)=>{
            state.myDownlinesArray = action.payload;
        },
        setMyDownlineLevel: (state, action)=>{
            state.myDownlineLevel = action.payload;
        },
        setGetUsername: (state, action)=>{
            state.getUsername = action.payload;
        },
        setPreviousUser: (state, action)=>{
            state.previousUser = action.payload;
        },
        setMyDirestReferrals: (state, action)=>{
            state.myDirestReferrals = action.payload;
        },
        resetAffiliate: ()=>initialState
    }
});
const { resetAffiliate , setCountMyDownlines , setMyDownlinesArray , setMyDownlineLevel , setMyUpline , setGetUsername , setPreviousUser , setMyDirestReferrals  } = AffiliateSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AffiliateSlice.reducer);


/***/ })

};
;