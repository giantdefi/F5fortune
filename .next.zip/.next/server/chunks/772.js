"use strict";
exports.id = 772;
exports.ids = [772];
exports.modules = {

/***/ 5772:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Gs": () => (/* binding */ setLeftSidebar),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "Zd": () => (/* binding */ setMainSidebarOpen),
/* harmony export */   "gu": () => (/* binding */ setLoginSidebar),
/* harmony export */   "hh": () => (/* binding */ setMainMenuItem),
/* harmony export */   "vh": () => (/* binding */ setDropdownOpen)
/* harmony export */ });
/* unused harmony exports mainMenuSlice, resetMainmenu, setCalculatorBackURL, setDrawerMenu, setItemSelected, setMenuActive, setUserTopMenu, setMtreeBackURL, setWalletHighlight */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    mainMenuItem: false,
    mainSidebarOpen: true,
    dropdownOpen: 0,
    itemSelected: 0,
    menuActive: 0,
    userTopMenu: 0,
    mtreeBackURL: false,
    calculatorBackURL: false,
    drawerMenu: false,
    loginSidebar: false,
    leftSidebar: false
};
const mainMenuSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "mainmenu",
    initialState,
    reducers: {
        setMainMenuItem: (state, action)=>{
            state.mainMenuItem = action.payload;
        },
        setMainSidebarOpen: (state, action)=>{
            state.mainSidebarOpen = action.payload;
        },
        setDropdownOpen: (state, action)=>{
            state.dropdownOpen = action.payload;
        },
        setItemSelected: (state, action)=>{
            state.itemSelected = action.payload;
        },
        setMenuActive: (state, action)=>{
            state.menuActive = action.payload;
        },
        setUserTopMenu: (state, action)=>{
            state.userTopMenu = action.payload;
        },
        setMtreeBackURL: (state, action)=>{
            state.mtreeBackURL = action.payload;
        },
        setMtreeBackURL: (state, action)=>{
            state.mtreeBackURL = action.payload;
        },
        setCalculatorBackURL: (state, action)=>{
            state.calculatorBackURL = action.payload;
        },
        setDrawerMenu: (state, action)=>{
            state.drawerMenu = action.payload;
        },
        setLoginSidebar: (state, action)=>{
            state.loginSidebar = action.payload;
        },
        setLeftSidebar: (state, action)=>{
            state.leftSidebar = action.payload;
        },
        resetMainmenu: ()=>initialState
    }
});
const { resetMainmenu , setMainMenuItem , setCalculatorBackURL , setMainSidebarOpen , setDropdownOpen , setDrawerMenu , setLoginSidebar , setLeftSidebar , setItemSelected , setMenuActive , setUserTopMenu , setMtreeBackURL , setWalletHighlight  } = mainMenuSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (mainMenuSlice.reducer);


/***/ })

};
;