"use strict";
exports.id = 467;
exports.ids = [467];
exports.modules = {

/***/ 1467:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Wallet)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5152);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var redux_reducers_SoundReducer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8475);





//---- REDUX STORE ---------------------


//--------------------------------------
function Wallet() {
    const itemRef1 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const itemRef2 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useDispatch)();
    const { e_wallet , r_wallet  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useSelector)((state)=>state.AuthReducer
    );
    const { width , domain , currency  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useSelector)((state)=>state.GeneralReducer
    );
    const { app_currency  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useSelector)((state)=>state.ConstantReducer
    );
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (itemRef1.current) {
            itemRef1.current.classList.add("flash");
            itemRef2.current.classList.add("flash");
        }
        setTimeout(()=>{
            if (itemRef1.current) {
                itemRef1.current.classList.remove("flash");
                itemRef2.current.classList.remove("flash");
            }
        }, 2000);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        e_wallet,
        r_wallet
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "flex justify-center items-center h-12 fixed top-[90px] md:top-[55px] right-0 z-10 bg-gray-900 ",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: " z-10 w-[450px] centered flex flex-row h-12 ",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex justify-end mr-5 mt-2 ",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex centered animated text-white",
                            ref: itemRef1,
                            children: [
                                "  E Wallet : ",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "/assets/img/coin.png",
                                    className: "ml-4",
                                    width: "20",
                                    alt: "dollar"
                                }),
                                " ",
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    className: "text-lg font-semi-bold ml-1",
                                    children: [
                                        " ",
                                        parseFloat(e_wallet).toLocaleString()
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex centered animated text-white ml-6",
                            ref: itemRef2,
                            children: [
                                "  R Wallet : ",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "/assets/img/coin.png",
                                    className: "ml-4",
                                    width: "20",
                                    alt: "dollar"
                                }),
                                " ",
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                    className: "text-lg font-semi-bold ml-1",
                                    children: [
                                        " ",
                                        parseFloat(r_wallet).toLocaleString()
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
};


/***/ }),

/***/ 8475:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Pl": () => (/* binding */ setPlaySound),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports ErrorSlice, resetSound */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    soundEffect: false
};
const ErrorSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "sound",
    initialState,
    reducers: {
        setPlaySound: (state, action)=>{
            state.soundEffect = action.payload;
        },
        resetSound: ()=>initialState
    }
});
const { resetSound , setPlaySound  } = ErrorSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ErrorSlice.reducer);


/***/ })

};
;