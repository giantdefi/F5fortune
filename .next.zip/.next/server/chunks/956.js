"use strict";
exports.id = 956;
exports.ids = [956];
exports.modules = {

/***/ 2009:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "n2": () => (/* binding */ resetErrors),
/* harmony export */   "sT": () => (/* binding */ setError)
/* harmony export */ });
/* unused harmony export errorSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    formError: false
};
const errorSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "error",
    initialState,
    reducers: {
        setError: (state, action)=>{
            state.formError = action.payload;
        },
        resetErrors: ()=>initialState
    }
});
const { resetErrors , setError  } = errorSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (errorSlice.reducer);


/***/ }),

/***/ 915:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DP": () => (/* binding */ setFormEmail),
/* harmony export */   "Fx": () => (/* binding */ resetForm),
/* harmony export */   "Jq": () => (/* binding */ setCurrentemail),
/* harmony export */   "LE": () => (/* binding */ setCurrentpassword),
/* harmony export */   "PT": () => (/* binding */ setFormConfirmPassword),
/* harmony export */   "Wb": () => (/* binding */ setWDWalletAmount),
/* harmony export */   "Wf": () => (/* binding */ setFormSponsor),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "ZQ": () => (/* binding */ setLastName),
/* harmony export */   "_X": () => (/* binding */ setWDCryptoAddress),
/* harmony export */   "cX": () => (/* binding */ setFormPassword),
/* harmony export */   "e4": () => (/* binding */ setDepositAmount),
/* harmony export */   "lC": () => (/* binding */ setFirstName),
/* harmony export */   "qI": () => (/* binding */ setNewEmail),
/* harmony export */   "qQ": () => (/* binding */ setFormPhone),
/* harmony export */   "rN": () => (/* binding */ setTransactionHash),
/* harmony export */   "ze": () => (/* binding */ setNewPassword)
/* harmony export */ });
/* unused harmony exports FormSlice, setFormName, setFormUsername, setConfirmPassword, setCountry, setNewPasswordConfirm */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    // registration form
    sponsor: false,
    name: false,
    username: false,
    email: false,
    phone: false,
    password: false,
    confirmPassword: false,
    country: false,
    firstName: false,
    lastName: false,
    //forgot pass
    // WD
    wdWalletAmount: false,
    walletAddr: false,
    //---wd wallet
    depositAmount: false,
    admWalletAddress: false,
    transactionHash: false,
    userWalletAddr: false,
    setSearchUsername: false,
    // change password
    currentpassword: false,
    newPassword: false,
    newPasswordConfirm: false,
    // change email
    currentemail: false,
    newEmail: false
};
const FormSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "form",
    initialState,
    reducers: {
        setFormSponsor: (state, action)=>{
            state.sponsor = action.payload;
        },
        setFormName: (state, action)=>{
            state.name = action.payload;
        },
        setFormUsername: (state, action)=>{
            state.username = action.payload;
        },
        setFirstName: (state, action)=>{
            state.firstName = action.payload;
        },
        setLastName: (state, action)=>{
            state.lastName = action.payload;
        },
        setFormPhone: (state, action)=>{
            state.phone = action.payload;
        },
        setFormEmail: (state, action)=>{
            state.email = action.payload;
        },
        setCurrentemail: (state, action)=>{
            state.currentemail = action.payload;
        },
        setNewEmail: (state, action)=>{
            state.newEmail = action.payload;
        },
        setFormPassword: (state, action)=>{
            state.password = action.payload;
        },
        setFormConfirmPassword: (state, action)=>{
            state.confirmPassword = action.payload;
        },
        setCountry: (state, action)=>{
            state.country = action.payload;
        },
        setWDWalletAmount: (state, action)=>{
            state.wdWalletAmount = action.payload;
        },
        setWDCryptoAddress: (state, action)=>{
            state.walletAddr = action.payload;
        },
        setTransactionHash: (state, action)=>{
            state.transactionHash = action.payload;
        },
        setDepositAmount: (state, action)=>{
            state.depositAmount = action.payload;
        },
        // change password
        setCurrentpassword: (state, action)=>{
            state.currentpassword = action.payload;
        },
        setNewPassword: (state, action)=>{
            state.newPassword = action.payload;
        },
        setNewPasswordConfirm: (state, action)=>{
            state.newPasswordConfirm = action.payload;
        },
        resetForm: ()=>initialState
    }
});
const { resetForm , setFormSponsor , setFormName , setFormUsername , setFormPhone , setFormPassword , setFormConfirmPassword , setFormEmail , setConfirmPassword , setCountry , setCurrentpassword , setNewPassword , setNewPasswordConfirm , setFirstName , setLastName , setWDWalletAmount , setWDCryptoAddress , setTransactionHash , setDepositAmount , setCurrentemail , setNewEmail  } = FormSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FormSlice.reducer);


/***/ })

};
;