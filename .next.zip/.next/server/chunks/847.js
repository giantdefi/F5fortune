"use strict";
exports.id = 847;
exports.ids = [847];
exports.modules = {

/***/ 8847:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports loaderSlice, resetLoader, setSpinner, setBtnSpinner, setBtnDisabled, setMenuSpinner, setLoaderBalance, setSpinnerAtVisitor, setSpinnerMtree, setSpinnerLoadUp, setSpinnerLoadBack, setSpinnerMtreeImage, setSpinnerAtLogo, setBuyEpinSpinner, setLoader, setBuyPackageSpinner */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    spinner: false,
    btnSpinner: false,
    btnDisabled: false,
    menuSpinner: false,
    loaderBalance: false,
    spinnerMtree: false,
    spinnerLoadUp: false,
    spinnerLoadBack: false,
    spinnerMtreeImage: false,
    spinnerAtVisitor: false,
    spinnerAtLogo: false,
    buyEpinSpinner: false,
    buyPackageSpinner: false,
    loader: false
};
const loaderSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "loader",
    initialState,
    reducers: {
        setSpinner: (state, action)=>{
            state.spinner = action.payload;
        },
        setBtnSpinner: (state, action)=>{
            state.btnSpinner = action.payload;
        },
        setBtnDisabled: (state, action)=>{
            state.btnDisabled = action.payload;
        },
        setMenuSpinner: (state, action)=>{
            state.menuSpinner = action.payload;
        },
        setLoaderBalance: (state, action)=>{
            state.loaderBalance = action.payload;
        },
        setSpinnerMtree: (state, action)=>{
            state.spinnerMtree = action.payload;
        },
        setSpinnerLoadUp: (state, action)=>{
            state.spinnerLoadUp = action.payload;
        },
        setSpinnerLoadBack: (state, action)=>{
            state.spinnerLoadBack = action.payload;
        },
        setSpinnerMtreeImage: (state, action)=>{
            state.spinnerMtreeImage = action.payload;
        },
        setSpinnerAtVisitor: (state, action)=>{
            state.spinnerAtVisitor = action.payload;
        },
        setSpinnerAtLogo: (state, action)=>{
            state.spinnerAtLogo = action.payload;
        },
        setBuyEpinSpinner: (state, action)=>{
            state.buyEpinSpinner = action.payload;
        },
        setBuyPackageSpinner: (state, action)=>{
            state.buyPackageSpinner = action.payload;
        },
        setLoader: (state, action)=>{
            state.loader = action.payload;
        },
        resetLoader: ()=>initialState
    }
});
const { resetLoader , setSpinner , setBtnSpinner , setBtnDisabled , setMenuSpinner , setLoaderBalance , setSpinnerAtVisitor , setSpinnerMtree , setSpinnerLoadUp , setSpinnerLoadBack , setSpinnerMtreeImage , setSpinnerAtLogo , setBuyEpinSpinner , setLoader , setBuyPackageSpinner  } = loaderSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (loaderSlice.reducer);


/***/ })

};
;