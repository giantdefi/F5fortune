"use strict";
exports.id = 191;
exports.ids = [191];
exports.modules = {

/***/ 6191:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Home)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var redux_reducers_MainmenuReducer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5772);
/* harmony import */ var redux_reducers_AuthReducer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2719);





//---- REDUX STORE ---------------------




//--------------------------------------
function Home() {
    const { domain , title , desc , crypto  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useSelector)((state)=>state.GeneralReducer
    );
    const { isLogin , phone , email , toggleLogin , wallet  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useSelector)((state)=>state.AuthReducer
    );
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useDispatch)();
    //   useEffect(() => {
    //     dispatch(setMainMenuItem(1))
    //     // eslint-disable-next-line react-hooks/exhaustive-deps
    //   }, [])
    //   const handleToggle = () => {
    //     dispatch(setToggleLogin(false))
    // }
    const handleToggle = ()=>{
        // if(toggleLogin){
        //     dispatch(setModalLogin(true))
        //     dispatch(setToggleLogin(false))
        // }else{
        //     dispatch(setModalRegister(true))
        //     dispatch(setToggleLogin(true))
        // }
        if (loginSidebar) {
            dispatch((0,redux_reducers_MainmenuReducer__WEBPACK_IMPORTED_MODULE_6__/* .setLoginSidebar */ .gu)(false));
        } else {
            dispatch((0,redux_reducers_MainmenuReducer__WEBPACK_IMPORTED_MODULE_6__/* .setLoginSidebar */ .gu)(true));
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_4___default()), {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                        children: title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "description",
                        content: desc
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("body", {
                className: "bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-100 ",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                    className: "relative min-h-screen bg-gray-400 dark:bg-[#111] animated fadeIn",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "_gradient_purple/90 w-full h-[600px] bg-cover bg-fixedAA ",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                            className: "min-h-screen bg-cover bg-center text-white py-20 ",
                            style: {
                                backgroundImage: "url(/assets/img/bg/trading-bg.avif)"
                            },
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "container mx-auto text-center ",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "text-5xl font-bold",
                                        children: "FIVEFORTUNE "
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-xl",
                                        children: "Invest in the Future of Finance with "
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "mt-4 text-2xl",
                                        children: "The easiest way to invest in top-performing cryptocurrencies. Secure, transparent, and profitable"
                                    })
                                ]
                            })
                        })
                    })
                })
            })
        ]
    });
};


/***/ })

};
;