"use strict";
exports.id = 111;
exports.ids = [111];
exports.modules = {

/***/ 6111:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$t": () => (/* binding */ setEffectiveDays),
/* harmony export */   "Am": () => (/* binding */ setAvailabletoWDDays),
/* harmony export */   "Z5": () => (/* binding */ setRunningProfit),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "fd": () => (/* binding */ resetStatement),
/* harmony export */   "ix": () => (/* binding */ setTotalEquity),
/* harmony export */   "uu": () => (/* binding */ setAvailabletoWDValue),
/* harmony export */   "zH": () => (/* binding */ setRunningDays)
/* harmony export */ });
/* unused harmony export StatementSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    totalEquity: false,
    runningDays: false,
    runningProfit: false,
    effectiveDays: false,
    availabletoWDDays: false,
    availabletoWDValue: false
};
const StatementSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "statement",
    initialState,
    reducers: {
        setTotalEquity: (state, action)=>{
            state.totalEquity = action.payload;
        },
        setRunningDays: (state, action)=>{
            state.runningDays = action.payload;
        },
        setRunningProfit: (state, action)=>{
            state.runningProfit = action.payload;
        },
        setEffectiveDays: (state, action)=>{
            state.effectiveDays = action.payload;
        },
        setAvailabletoWDDays: (state, action)=>{
            state.availabletoWDDays = action.payload;
        },
        setAvailabletoWDValue: (state, action)=>{
            state.availabletoWDValue = action.payload;
        },
        resetStatement: ()=>initialState
    }
});
const { resetStatement , setTotalEquity , setRunningDays , setRunningProfit , setEffectiveDays , setAvailabletoWDDays , setAvailabletoWDValue  } = StatementSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StatementSlice.reducer);


/***/ })

};
;